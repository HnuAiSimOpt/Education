import pandas as pd
import matplotlib.pyplot as plt
import warnings
from sklearn.metrics import *
from sklearn.preprocessing import *
from math import sqrt
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.svm import SVR
import numpy as np

warnings.filterwarnings("ignore")
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
pd.set_option('display.max_rows', 100, 'display.max_columns', 1000, "display.max_colwidth", 1000, 'display.width', 1000)


def evaluation(model, x_test, y_test):
    ypred = model.predict(x_test)
    mae = mean_absolute_error(y_test, ypred)
    mse = mean_squared_error(y_test, ypred)
    rmse = sqrt(mse)
    r2 = r2_score(y_test, ypred)
    print("MAE: %.4f" % mae)
    print("MSE: %.4f" % mse)
    print("RMSE: %.4f" % rmse)
    print("R^2: %.4f" % r2)
    return ypred, r2


def plot_scatter_with_lines(train_exp, train_pre, test_exp, test_pre, r2_value):
    plt.figure(figsize=(8, 6))

    # 绘制训练集和测试集
    plt.scatter(train_exp, train_pre, marker='o', s=25, color='blue', label='Train dataset')
    plt.scatter(test_exp, test_pre, marker='o', s=25, color='red', label='Test dataset')

    # 统一坐标范围
    min_val, max_val = 5e2, 2e3
    x_line = np.logspace(np.log10(min_val), np.log10(max_val), 500)

    # 理想线 (y=x)
    plt.plot(x_line, x_line, 'k--', label='Ideal line')

    # 1.5倍误差带 (乘法关系)
    plt.fill_between(x_line, x_line / 1.2, x_line * 1.2, color='green', alpha=0.2, label='1.2x error band')

    # 对数坐标 + 范围限制
    plt.xscale('log')
    plt.yscale('log')
    plt.xlim(min_val, max_val)
    plt.ylim(min_val, max_val)

    # 坐标轴与标题
    plt.xlabel('Experimental UTS (MPa)', fontsize=12)
    plt.ylabel('Predicted UTS (MPa)', fontsize=12)
    plt.title('SVR Model: Experimental vs. Predicted UTS (Log-Log)')

    # 在图上标注R²值
    plt.text(0.95, 0.05, f"$R^2$ = {r2_value:.4f}",
             transform=plt.gca().transAxes,
             fontsize=12, bbox=dict(facecolor='white', alpha=0.6),
             ha='right', va='bottom')

    plt.legend()
    plt.grid(True, which="both", ls="--", linewidth=0.5)
    plt.savefig('svr_prediction_scatter_log.png', dpi=300)
    plt.show()


# 读取数据
data = pd.read_excel('Inconel718_parameters_mechanical_properties.xlsx')

X = data.iloc[:, :-1].values
y = data.iloc[:, -1].values
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1)

scaler_x = MinMaxScaler()
x_train = scaler_x.fit_transform(x_train)
x_test = scaler_x.transform(x_test)

scaler_y = MinMaxScaler()
y_train = scaler_y.fit_transform(y_train.reshape(-1, 1)).ravel()
y_test = scaler_y.transform(y_test.reshape(-1, 1)).ravel()

# SVR模型
svr_model = SVR(
    C=50,
    epsilon=0.0059,
    gamma=0.2,
    kernel='rbf'
)

svr_model.fit(x_train, y_train)

print("SVR")
print("params: ", svr_model.get_params())
print("train score: ", svr_model.score(x_train, y_train))
print("test score: ", svr_model.score(x_test, y_test))

# 训练集预测
y_train_pred = svr_model.predict(x_train)
y_train_pred_D = scaler_y.inverse_transform(y_train_pred.reshape(-1, 1))
y_train_D = scaler_y.inverse_transform(y_train.reshape(-1, 1))

# 测试集预测
y_test_pred, r2_value = evaluation(svr_model, x_test, y_test)
Pre_Life_D = scaler_y.inverse_transform(y_test_pred.reshape(-1, 1))
Exp_Life_D = scaler_y.inverse_transform(y_test.reshape(-1, 1))

# 画图
plot_scatter_with_lines(y_train_D, y_train_pred_D, Exp_Life_D, Pre_Life_D, r2_value)
