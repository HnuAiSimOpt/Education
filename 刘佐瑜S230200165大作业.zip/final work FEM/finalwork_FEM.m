% -------------------------------------------------------------------------
%   project name: finalwork_FEM
%   
%   program purpose : FEM homework
% 
%   program description : 二维梁单元3300单元数的有限元分析程序
% 
%   date : 2023-12-25
% 
%   by : Zuoyu Liu(刘佐瑜)
% 
%   S230200165
%
% -------------------------------------------------------------------------
%% 项目基本属性定义
s=1;                                                                        %积分方式判定标志，1代表精确积分，0代表减缩积分
%定义材料基本属性
l=20;   b=6;    t=3;                                                        %对象基本尺寸

ex=4.2e7;   v=0.31;     izz=t*b^3/12;                                       %材料物理特性                                                                   
p=180;                                                                      %剪切应力
%有限元单元划分
nx=165;     ny=20;                                                          %x、y方向划分段数
%计算函数初始化
d=str_mat(v,ex);                                                            %应力应变本构关系生成函数
[xloc,yloc,~]=nodecs(l,b,nx,ny);                                            %节点坐标定义程序
k=mat_totals(s,d,xloc,yloc);                                                %总刚度矩阵生成程序
tao=forceray(b,t,p,yloc);                                                   %等效节点荷载阵列生成程序
[q,ttt]=bound(k,tao,xloc,yloc);                                             %边界条件引入程序——罚函数法
u=q\ttt;                                                                    %求解节点位移
[ux,uy]=result(xloc,u);                                                     %节点位移集成程序
[errx,erry,errfx,errfy,errfs]=errorall(ux,uy,xloc,yloc,ex,izz,v,p);         %误差范数计算程序
e=[errx erry errfx errfy errfs]';                                           %各个误差范数表达阵列

%% 绘图

[m,n]=size(xloc);
[ux,uy]=result(xloc,u);
stx=zeros(11,111);                                                          %x向应力描述数组
sty= zeros(11,111);                                                         %y向应力描述数组
sts= zeros(11,111);                                                         %切应力描述数组
disx= zeros(11,111);                                                        %x向位移描述数组
disy= zeros(11,111);                                                        %y向位移描述数组

for i=1:11
    for j=1:111
        [disp,stress]=post((j-1)*l/110,(i-1)*b/11-0.5*b,ux,uy,xloc,yloc);
        stx(i,j)=stress(1,1);
        sty(i,j)=stress(2,1);
        sts(i,j)=stress(3,1);
        disx(i,j)=disp(1,1);
        disy(i,j)=disp(2,1);
    end
end


figure

subplot(2,1,1)

xx=linspace(0,l,111)
yy=linspace(-0.5*b,0.5*b,11)


pcolor(xx,yy,stx);                                                          %绘制x向应力云图
title('受力云图')
colormap('jet')
colorbar;
% shading interp;

subplot(2,1,2)

pcolor(xx,yy,disx);
title('位移云图')
colormap('jet')
colorbar;
% shading interp;

% -------------------------------------------------------------------------
%                            计算函数定义
% -------------------------------------------------------------------------
%% 点坐标生成程序nodecs
function [xloc,yloc,nodenum]=nodecs(l,b,nx,ny)

    dx=l/nx;
    dy=b/ny;
    nxnode=nx+1;
    nynode=ny+1;
    xloc=zeros(nynode,nxnode);                                              %xloc矩阵记录梁平面内各个节点的横坐标
    yloc=zeros(nynode,nxnode);                                              %yloc矩阵记录梁平面内各个节点的纵坐标
    nodenum=zeros(nynode-1,nxnode-1);

    for i=1:nynode
        for j=1:nxnode
            xloc(i,j)=dx*(j-1);
            yloc(i,j)=-0.5*b+dy*(i-1);
        end
    end

    for i=1:nynode-1
        for j=1:nxnode-1
            nodenum(i,j)=(i-1)*(nxnode-1)+j;
        end
    end
    
end
    
%% 应力应变关系矩阵生成程序str_mat
function d=str_mat(v,ex)

    d=zeros(3,3);
    d(1,1)=1;
    d(2,2)=1;
    d(1,2)=v;
    d(2,1)=v;
    d(3,3)=(1-v)/2;
    d=d*ex/(1-v^2);
end

%% 应变插值矩阵的生成程序bmaxtrix
function b=bmaxtrix(x,y,xloc,yloc)

    [m,n]=size(xloc);
    l=xloc(1,n);
    b=-2*yloc(1,1);
    dx=l/(n-1);
    dy=b/(m-1);

    if x==l
        kesi=1;                                                             %x的自然坐标
    else
        kesi=2*(rem(x,dx)-0.5*dx)/dx; 
    end

    if y==0.5*b
        yeta=1;                                                             %y的自然坐标
    else
        yeta=2*(rem(y+0.5*b,dy)-0.5*dy)/dy;
    end

    b=zeros(3,8);
    b(1,1)=0.5*dy*(1+yeta);
    b(2,2)=0.5*dx*(1+kesi);
    b(3,1)=0.5*dx*(1+kesi);
    b(3,2)=0.5*dy*(1+yeta);
    b(1,3)=0.5*dy*(1-yeta);
    b(2,4)=-0.5*dx*(1+kesi);
    b(3,3)=-0.5*dx*(1+kesi);
    b(3,4)=0.5*dy*(1-yeta);
    b(1,5)=-0.5*dy*(1-yeta);
    b(2,6)=-0.5*dx*(1-kesi);
    b(3,5)=-0.5*dx*(1-kesi);
    b(3,6)=-0.5*dy*(1-yeta);
    b(1,7)=-0.5*dy*(1+yeta);
    b(2,8)=0.5*dx*(1-kesi);
    b(3,7)=0.5*dx*(1-kesi);
    b(3,8)=-0.5*dy*(1+yeta);
    b=b/dx/dy;

end

%% 单元刚度矩阵的生成程序stif_mat
function ke=stif_mat(i,s,d,xloc,yloc)

    [m,n]=size(xloc);
    l=xloc(1,n);
    b=-2*yloc(1,1);
    dx=l/(n-1);
    dy=b/(m-1);
    nx=n-1;
    cc=mod(i,nx);

    if cc==0
        y0=(i/nx-1)*dy-0.5*b;                                               %判定第i个单元的起点坐标
        x0=(nx-1)*dx;
    else
        x0=(rem(i,nx)-1)*dx;
        y0=(i-rem(i,nx))/nx*dy-0.5*b;
    end

    if s==1                                                                 %此处为精确积分
        x1=x0+0.5*dx*(1+1/sqrt(3));                                         %采用2x2的高斯积分方式
        y1=y0+0.5*dy*(1+1/sqrt(3));

        x2=x0+0.5*dx*(1+1/sqrt(3));
        y2=y0+0.5*dy*(1-1/sqrt(3));    
        
        x3=x0+0.5*dx*(1-1/sqrt(3));
        y3=y0+0.5*dy*(1-1/sqrt(3)); 

        x4=x0+0.5*dx*(1-1/sqrt(3));
        y4=y0+0.5*dy*(1+1/sqrt(3)); 

        ke=0.25*dx*dy*bmaxtrix(x1,y1,xloc,yloc)'*...
            d*bmaxtrix(x1,y1,xloc,yloc);
        ke=ke+0.25*dx*dy*bmaxtrix(x2,y2,xloc,yloc)'*...
            d*bmaxtrix(x2,y2,xloc,yloc);
        ke=ke+0.25*dx*dy*bmaxtrix(x3,y3,xloc,yloc)'*...
            d*bmaxtrix(x3,y3,xloc,yloc);
        ke=ke+0.25*dx*dy*bmaxtrix(x4,y4,xloc,yloc)'*...
            d*bmaxtrix(x4,y4,xloc,yloc);
    end

    if s==0                                                                 %此处为减缩积分
        x1=x0+0.5*dx;                                                       %采用2x1的减缩积分方式
        y1=y0+0.5*dy*(1+1/sqrt(3));

        x2=x0+0.5*dx;
        y2=y0+0.5*dy*(1-1/sqrt(3)); 

        ke=2*0.25*dx*dy*bmaxtrix(x1,y1,xloc,yloc)'*...
            d*bmaxtrix(x1,y1,xloc,yloc);
        ke=ke+2*0.25*dx*dy*bmaxtrix(x2,y2,xloc,yloc)'*...
        d*bmaxtrix(x2,y2,xloc,yloc);
    end

end

%% 总刚度矩阵的生成程序mat_totals
function k=mat_totals(s,d,xloc,yloc)

    [m,n]=size(xloc);
    nnode=m*n;
    k=zeros(2*nnode,2*nnode);
    nele=(m-1)*(n-1);

    for i=1:nele
        g=zeros(8,2*nnode);                                                 %单元刚度矩阵的位置传递矩阵G                
        cc=mod(i,n-1);

        if cc==0
            n0=i/(n-1)*n-1;                                                 %判定当前所集成单元的起点编号               
            else
            n0=rem(i,n-1)+(i-rem(i,n-1))/(n-1)*n;
        end

        ke=stif_mat(i,s,d,xloc,yloc);

        a1=n0+1+n;
        a2=n0+1;
        a3=n0;
        a4=n0+n;

        g(1,2*a1-1)=1;
        g(2,2*a1)=1;
        g(3,2*a2-1)=1;
        g(4,2*a2)=1;    
        g(5,2*a3-1)=1;
        g(6,2*a3)=1;    
        g(7,2*a4-1)=1;
        g(8,2*a4)=1;    

        k=k+g'*ke*g;

    end

end

%% 等效节点荷载阵列生成程序forceray
function tao=forceray(b,t,p,yloc)

    [m,n]=size(yloc);
    nnode=m*n;
    tao=zeros(2*nnode,1);
    izz=t*b^3/12;
    dy=b/(m-1);
    pp=p/2/izz;

    s1=-1/sqrt(3);
    s2=1/sqrt(3);

    q11=(1-s1)/2;
    q12=(1-s2)/2;
    q21=(1+s1)/2;
    q22=(1+s2)/2;

    for i=1:m-1
        y1=-b/2+(i-1)*dy;
        y2=-b/2+i*dy;
        
        Q11=q11*pp*((s1*dy/2+(y1+y2)/2)^2-b^2/4)*dy/2;
        Q12=q12*pp*((s2*dy/2+(y1+y2)/2)^2-b^2/4)*dy/2;
        Q21=q21*pp*((s1*dy/2+(y1+y2)/2)^2-b^2/4)*dy/2;
        Q22=q22*pp*((s2*dy/2+(y1+y2)/2)^2-b^2/4)*dy/2;
    
        k1=2*(n)*i;
        k2=2*(n)*(i+1);

        f1=Q11+Q12;
        f2=Q21+Q22;

        tao(k1)=tao(k1)+f1;
        tao(k2)=tao(k2)+f2;
    end

end

%% 强制边界条件引入程序bound
function [k1,tao]=bound(k,ttt,xloc,yloc)

    k1=k;                                                                   %结构总刚度矩阵
    tao=ttt;                                                                %等效节点荷载阵列
    [m,n]=size(yloc);
    l=xloc(1,n);
    b=-2*yloc(1,1);
    t=1;
    dy=b/(m-1);
    alpha=1e25;                                                             %罚数
    ex=3e7;
    v=0.2;
    izz=t*b^3/12;
    p=200;

    for i=1:m
        nux=2*n*(i-1)+1;
        nuy=2*n*(i-1)+2;

        y=-b/2+(i-1)*dy;

        ux=p*y/6/ex/izz*(2+v)*(y^2-b^2/4);
        uy=-p*v*l*y^2/2/ex/izz;

        k1(nux,nux)=alpha*k(nux,nux);
        k1(nuy,nuy)=alpha*k(nuy,nuy);

        tao(nux)=ux*k1(nux,nux);
        tao(nuy)=uy*k1(nuy,nuy);
    end

end

%% 位移向量矩阵表示的程序result
function [ux,uy]=result(xloc,u)

    [m,n]=size(xloc);
    ux=zeros(m,n);
    uy=ux;

    for i=1:m
        for j=1:n
            ux(i,j)=u(2*((i-1)*n+(j-1))+1,1);                               %横向位移记录矩阵
            uy(i,j)=u(2*((i-1)*n+(j-1))+2,1);                               %纵向位移记录矩阵
        end
    end

end

%% 任一点位移和应力输出程序post
function [disp,stress]=post(x,y,ux,uy,xloc,yloc)

    [m,n]=size(xloc);
    l=xloc(1,n);
    b=-2*yloc(1,1);
    dx=l/(n-1);
    dy=b/(m-1);

    if x==l
        n1=n-1;
    else
        n1=(x-rem(x,dx))/dx+1;
        n1=round(n1);
    end

    if y==0.5*b
        n2=m-1;
    else
        n2=(0.5*b+y-rem(0.5*b+y,dy))/dy+1;
        n2=round(n2);
    end
    
    kesi=(x-dx*(n1-0.5))/0.5/dx;
    yeta=(y+0.5*b-dy*(n2-0.5))/0.5/dy;

    nn1=0.25*(1+kesi)*(1+yeta);
    nn2=0.25*(1+kesi)*(1-yeta);
    nn3=0.25*(1-kesi)*(1-yeta);
    nn4=0.25*(1-kesi)*(1+yeta);

    disp=zeros(2,1);                                                        %任意一点位移，由四周的节点差值求得
    disp(1,1)=nn1*ux(n2+1,n1+1)+nn2*ux(n2,n1+1)+...
        nn3*ux(n2,n1)+nn4*ux(n2+1,n1);
    disp(2,1)=nn1*uy(n2+1,n1+1)+nn2*uy(n2,n1+1)+...
        nn3*uy(n2,n1)+nn4*uy(n2+1,n1);

    bbb=bmaxtrix(x,y,xloc,yloc);

    ae=[ux(n2+1,n1+1) uy(n2+1,n1+1) ux(n2,n1+1) uy(n2,n1+1) ...
        ux(n2,n1) uy(n2,n1) ux(n2+1,n1) uy(n2+1,n1)]';
    strain=bbb*ae;
    d=str_mat(0.2,3e7);
    stress=d*strain;                                                        %任意一点应力，由本构和应变求得

end

%% 理论解计算程序realfact
function [xc,yc,fx,fy,fs]=realfact(x,y,ex,izz,v,p,l,b)

    xc=p*y/6/ex/izz*((6*l-3*x)*x+(2+v)*(y^2-0.25*b^2));                     %横向位移理论解
    yc=-p/6/ex/izz*(3*v*y^2*(l-x)+(4+5*v)*x*0.25*b^2+x^2*(3*l-x));          %纵向位移理论解
    fy=0;                                                                   %y向正应力理论解
    fx=p*y/izz*(l-x);                                                       %x向正应力理论解
    fs=p/2/izz*(y^2-0.25*b^2);                                              %切应力理论解

end

%% 误差计算程序errorall
function [errx,erry,errfx,errfy,errfs]=errorall(ux,uy,xloc,yloc,ex,izz,v,p)

    [m,n]=size(xloc);
    nele=(m-1)*(n-1);
    l=xloc(1,n);
    b=-2*yloc(1,1);
    dx=l/(n-1);
    dy=b/(m-1);
    
    errx=0;                                                                 %x向位移的二范数误差
    erry=0;                                                                 %y向位移的二范数误差
    errfx=0;                                                                %x向正应力的二范数误差
    errfy=0;                                                                %y向正应力的二范数误差
    errfs=0;                                                                %切应力的二范数误差

    for i=1:nele
        cc=rem(i,n-1);
        if cc==0
            nx0=n-1;
            ny0=i/(n-1);
        else
            nx0=rem(i,n-1);
            ny0=(i-rem(i,n-1))/(n-1)+1;
        end

        x0=xloc(ny0,nx0);
        y0=yloc(ny0,nx0);

        x1=x0+(1+1/sqrt(3))*0.5*dx;
        x2=x0+(1-1/sqrt(3))*0.5*dx;

        y1=y0+(1+1/sqrt(3))*0.5*dy;
        y2=y0+(1-1/sqrt(3))*0.5*dy;

        [disp1,stress1]=post(x1,y1,ux,uy,xloc,yloc);
        [disp2,stress2]=post(x1,y2,ux,uy,xloc,yloc);
        [disp3,stress3]=post(x2,y1,ux,uy,xloc,yloc);
        [disp4,stress4]=post(x2,y2,ux,uy,xloc,yloc);

        [xc1,yc1,fx1,fy1,fs1]=realfact(x1,y1,ex,izz,v,p,l,b);
        [xc2,yc2,fx2,fy2,fs2]=realfact(x1,y2,ex,izz,v,p,l,b);
        [xc3,yc3,fx3,fy3,fs3]=realfact(x2,y1,ex,izz,v,p,l,b);
        [xc4,yc4,fx4,fy4,fs4]=realfact(x2,y2,ex,izz,v,p,l,b);               %以下全部采用2x2的高斯积分

        delta1=0.25*dx*dy*(disp1(1,1)+disp2(1,1)+disp3(1,1)+...
            disp4(1,1)-xc1-xc2-xc3-xc4);
        delta2=0.25*dx*dy*(disp1(2,1)+disp2(2,1)+disp3(2,1)+...
            disp4(2,1)-yc1-yc2-yc3-yc4);
        delta3=0.25*dx*dy*(stress1(1,1)+stress2(1,1)+stress3(1,1)+...
            stress4(1,1)-fx1-fx2-fx3-fx4);
        delta4=0.25*dx*dy*(stress1(2,1)+stress2(2,1)+stress3(2,1)+...
            stress4(2,1)-fy1-fy2-fy3-fy4);
        delta5=0.25*dx*dy*(stress1(3,1)+stress2(3,1)+stress3(3,1)+...
            stress4(3,1)-fs1-fs2-fs3-fs4);

        errx=errx+(delta1)^2;
        erry=erry+(delta2)^2;
        errfx=errfx+(delta3)^2;
        errfy=errfy+(delta4)^2;
        errfs=errfs+(delta5)^2;

    end

    errx=sqrt(errx);
    erry=sqrt(erry);
    errfx=sqrt(errfx);
    errfy=sqrt(errfy);
    errfs=sqrt(errfs);

end

%% 节点编号判定程序maxloc
function q=maxloc(n0,n,i)                                                   %该程序作为子程序被总刚度矩阵生成程序totals调用，根据既有单元的节点号，判定节点对应在节点位移向量中的位置。
    if i==1
        q=2*n0+2*n+1;
    end

    if i==2
        q=2*n0+2*n+2;
    end

    if i==3
        q=2*n0+1;
    end

    if i==4
        q=2*n0+2;
    end

    if i==5
        q=2*n0-1;
    end

    if i==6
        q=2*n0;
    end

    if i==7
        q=2*n0+2*n-1;
    end

    if i==8
        q=2*n0+2*n;
    end

end