# -*- coding: utf-8 -*-
"""
Created on Sat Mar 25 14:48:01 2023

@author: 86186
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Mar 22 14:40:43 2023

@author: 86186
"""
import numpy as np
#输入房价数据
x_data=np.array([7,8,9,10,11,12,1,2,3])
y_data=np.array([10502,10558,10646,10661,10649,10688,10829,10770,10703])
#定义拉格朗日差值函数,作为预测函数
def lagrange(x_data,y_data,x):
    n=len(x_data)
    y=0
    for i in range(n):
        L=1
        for j in range(n):
            if i!=j:
                L*=(x-x_data[j])/(x_data[i]-x_data[j])
        y+=y_data[i]*L
    return y
#需要预测的月份
xf=np.array([4,5,6])
#代入预测函数得到房价预测值
yf=lagrange(x_data,y_data,xf)
#输出预测值
print('未来三个月房价分别是{}'.format(yf))
