# -*- coding: utf-8 -*-
"""
Created on Wed Mar 22 14:40:43 2023

@author: 86186
"""

import numpy as np
import matplotlib.pyplot as plt
#定义要差值的函数
def f(x):
    return 1/(1+x**2)
#定义拉格朗日差值函数
def lagrange(x_data,y_data,x):
    n=len(x_data)
    y=0
    for i in range(n):
        L=1
        for j in range(n):
            if i!=j:
                L*=(x-x_data[j])/(x_data[i]-x_data[j])
        y+=y_data[i]*L
    return y
#在[-5，5]生成k个数据点
k=[2,4,6,8,10,12,16,20]
for a in range(8):
    x_data=np.linspace(-5,5,k[a])
    y_data=f(x_data)    
#在[-5，5]生成100个数据点用于绘图
    x=np.linspace(-5,5,401)
    y=f(x)
#对这k个点进行拉格朗日插值
    y_lagrange=lagrange(x_data,y_data,x)
#绘制原函数和插值函数图像
    plt.plot(x,y,label='原函数')
    plt.plot(x,y_lagrange,label='节点数n={}差值函数'.format(k[a]))
    plt.scatter(x_data,y_data,color='red',label='插值点')
    plt.legend()
    plt.show()