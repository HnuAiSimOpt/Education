function [K]=cal_K_FEM_Hex8(sdof,nel,nnel,nodes,gcoord,edof,matmtx,ndof)
K=sparse(sdof,sdof);		% initialization of global stiffness matrix
nglx=2;
ngly=2;
nglz=2;
[point,weight]=feglqd2(nglx,ngly,nglz);
for iel=1:nel       %loop for the total number of element
    for i=1:nnel    % loop for 8 nodes of (iel)-th element
        nod(i)=nodes(iel,i);    % extract nodes for (iel)-th element
        xco(i)=gcoord(nod(i),1);   % extract x value of the node
        yco(i)=gcoord(nod(i),2);   % extract y value of the node
        zco(i)=gcoord(nod(i),3);   % extract z value of the node
    end 
    Ke=sparse(edof,edof);	   % initialization of element stiffness matrix   

 for intx=1:nglx
        kesi=point(intx,1);        %sampling point in x-axis   
        wtx=weight(intx,1);        %weight in x-axis           
        for inty=1:ngly
            yita=point(inty,2);    %sampling point in y-axis  
            wty=weight(inty,2);    %weight in y-axis
            for intz=1:nglz
                zeta=point(intz,3);
                wtz=weight(intz,3);
        [shape,dNdr,dNds,dNdt]=get_shape_Hex8(kesi,yita,zeta); 
        jacob=cal_jacob_Hex8(nnel,dNdr,dNds,dNdt,xco,yco,zco); 
        det_jacob=det(jacob);  
        inv_jacob=inv(jacob); 
        [dNdx,dNdy,dNdz]=get_dNdx_Hex8(nnel,dNdr,dNds,dNdt,inv_jacob);
        B=get_Bmat_Hex8(nnel,dNdx,dNdy,dNdz);         
        Ke=Ke+B'*matmtx*B*wtx*wty*wtz*det_jacob; 
            end
        end
  end
        index = get_eledof(nod,nnel,ndof);    % extract system dofs for the element 
        K(index,index) = K(index,index) + Ke; % assemble element stiffness matrices  
end