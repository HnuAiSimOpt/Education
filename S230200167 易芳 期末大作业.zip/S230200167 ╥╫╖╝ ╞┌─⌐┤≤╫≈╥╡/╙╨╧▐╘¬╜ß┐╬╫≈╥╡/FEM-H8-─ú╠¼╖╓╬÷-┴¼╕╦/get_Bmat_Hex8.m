function [Be]=get_Bmat_Hex8(nnel,dNdx,dNdy,dNdz)
for i=1:nnel
    i1=(i-1)*3+1;  
    i2=i1+1;
    i3=i1+2;
    Be(1,i1)=dNdx(i);
    Be(2,i2)=dNdy(i);
    Be(3,i3)=dNdz(i);
    
    Be(4,i1)=dNdy(i);
    Be(4,i2)=dNdx(i);
    
    Be(5,i2)=dNdz(i);
    Be(5,i3)=dNdy(i);  
    
    Be(6,i1)=dNdz(i);  
    Be(6,i3)=dNdx(i);
    
    
 end