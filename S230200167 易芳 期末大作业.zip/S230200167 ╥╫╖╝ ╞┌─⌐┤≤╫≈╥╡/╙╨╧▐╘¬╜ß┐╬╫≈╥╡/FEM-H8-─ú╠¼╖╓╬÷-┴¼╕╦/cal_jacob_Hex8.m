function [jacob]=cal_jacob_Hex8(nnel,dNdr,dNds,dNdt,xco,yco,zco)
 jacob=zeros(3,3);
 for i=1:nnel
    jacob(1,1)=jacob(1,1)+dNdr(i)*xco(i);
    jacob(1,2)=jacob(1,2)+dNdr(i)*yco(i);
    jacob(1,3)=jacob(1,3)+dNdr(i)*zco(i);
    jacob(2,1)=jacob(2,1)+dNds(i)*xco(i);
    jacob(2,2)=jacob(2,2)+dNds(i)*yco(i);
    jacob(2,3)=jacob(2,3)+dNds(i)*zco(i);
    jacob(3,1)=jacob(3,1)+dNdt(i)*xco(i);
    jacob(3,2)=jacob(3,2)+dNdt(i)*yco(i);
    jacob(3,3)=jacob(3,3)+dNdt(i)*zco(i);
 end
