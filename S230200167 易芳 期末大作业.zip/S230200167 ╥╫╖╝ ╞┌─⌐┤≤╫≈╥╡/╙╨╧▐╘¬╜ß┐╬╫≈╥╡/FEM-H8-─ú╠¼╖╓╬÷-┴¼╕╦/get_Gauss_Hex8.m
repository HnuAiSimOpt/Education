function [point,wieght]=get_Gauss_Hex8
gp=1/sqrt(3);
point=[-gp -gp -gp;gp -gp -gp;gp gp -gp;-gp gp -gp; -gp -gp gp;gp -gp gp;gp gp gp;-gp gp gp];
wieght=[1,1,1];