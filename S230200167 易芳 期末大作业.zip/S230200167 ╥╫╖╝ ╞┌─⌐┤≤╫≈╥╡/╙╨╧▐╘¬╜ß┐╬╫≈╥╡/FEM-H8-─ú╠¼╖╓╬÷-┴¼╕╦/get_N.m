function  [N]=get_N(shape)
for i=1:8
N(1,(i-1)*3+1)=shape(i);
N(2,(i-1)*3+2)=shape(i);
N(3,(i-1)*3+3)=shape(i);
end
% for i=1:24
%     N(i,i)=1;
% end
