clc;
clear;
mode2=[6.744275206	1.964914685	0.561199105	0.373619055];
mode4=[5.065066539	1.632369845	0.484664102	0.32505748];
mode6=[0.426003292	0.181342535	0.070720856	0.050881877];
mode8=[3.733647794	1.362914555	0.420138431	0.283156637];
num_nodes=[99,525,3321,6171];
plot(num_nodes,mode2,'-^m','MarkerSize',6,'linewidth',1.5);hold on;
plot(num_nodes,mode4,'-sb','MarkerSize',6,'linewidth',1.5);hold on;
plot(num_nodes,mode6,'-oc','MarkerSize',6,'linewidth',1.5);hold on;
plot(num_nodes,mode8,'->g','MarkerSize',6,'linewidth',1.5);hold on;

set(gca,'FontSize',14);
legend('\fontsize{14}\rm\fontname{helvetica}�ڶ���',...
       '\fontsize{14}\rm\fontname{helvetica}���Ľ�',...
       '\fontsize{14}\rm\fontname{helvetica}������',...
       '\fontsize{14}\rm\fontname{helvetica}�ڰ˽�',...
       'Location','North')
ylabel('\fontsize{14}\rm\fontname{Times New Roman}Relative error(%)')
xlabel('\fontsize{14}\rm\fontname{Times New Roman}Number of nodes')