function [matmtrx]=fematiso(emodule,poisson)

%------------------------------------------------------------------------
%  Purpose:
%     determine the constitutive equation for isotropic material ȷ������ͬ�Բ��ϵı�������
%
%  Variable Description:
%     emodule - elastic modulus
%     poisson - Poisson's ratio   
%     emodule - ����ģ��
%     poisson - ���ɱ�
%------------------------------------------------------------------------

% three-dimension
   matmtrx=emodule/((1+poisson)*(1-2*poisson))* ...
   [(1-poisson)  poisson  poisson   0   0    0; 
   poisson  (1-poisson)   poisson   0   0    0;
   poisson  poisson  (1-poisson)    0   0    0;
   0    0    0    (1-2*poisson)/2   0    0;
   0    0    0    0    (1-2*poisson)/2   0;
   0    0    0    0    0   (1-2*poisson)/2];

 end