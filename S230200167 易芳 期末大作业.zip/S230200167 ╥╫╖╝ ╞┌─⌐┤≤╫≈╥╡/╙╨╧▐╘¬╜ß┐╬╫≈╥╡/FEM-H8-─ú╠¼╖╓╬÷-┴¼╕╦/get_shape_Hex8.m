function [shape,dNdr,dNds,dNdt]=get_shape_Hex8(kesi,yita,zeta)
 shape(1)=1/8*(1-kesi)*(1-yita)*(1-zeta);
 shape(2)=1/8*(1+kesi)*(1-yita)*(1-zeta);
 shape(3)=1/8*(1+kesi)*(1+yita)*(1-zeta);
 shape(4)=1/8*(1-kesi)*(1+yita)*(1-zeta);
 shape(5)=1/8*(1-kesi)*(1-yita)*(1+zeta);
 shape(6)=1/8*(1+kesi)*(1-yita)*(1+zeta);
 shape(7)=1/8*(1+kesi)*(1+yita)*(1+zeta);
 shape(8)=1/8*(1-kesi)*(1+yita)*(1+zeta);
 
 dNdr(1)=-1/8*(1-yita)*(1-zeta);
 dNdr(2)=1/8*(1-yita)*(1-zeta);
 dNdr(3)=1/8*(1+yita)*(1-zeta);
 dNdr(4)=-1/8*(1+yita)*(1-zeta);
 dNdr(5)=-1/8*(1-yita)*(1+zeta);
 dNdr(6)=1/8*(1-yita)*(1+zeta);
 dNdr(7)=1/8*(1+yita)*(1+zeta);
 dNdr(8)=-1/8*(1+yita)*(1+zeta);
 
 dNds(1)=-1/8*(1-kesi)*(1-zeta);
 dNds(2)=-1/8*(1+kesi)*(1-zeta);
 dNds(3)=1/8*(1+kesi)*(1-zeta);
 dNds(4)=1/8*(1-kesi)*(1-zeta);
 dNds(5)=-1/8*(1-kesi)*(1+zeta);
 dNds(6)=-1/8*(1+kesi)*(1+zeta);
 dNds(7)=1/8*(1+kesi)*(1+zeta);
 dNds(8)=1/8*(1-kesi)*(1+zeta);
 
 dNdt(1)=-1/8*(1-kesi)*(1-yita);
 dNdt(2)=-1/8*(1+kesi)*(1-yita);
 dNdt(3)=-1/8*(1+kesi)*(1+yita);
 dNdt(4)=-1/8*(1-kesi)*(1+yita);
 dNdt(5)=1/8*(1-kesi)*(1-yita);
 dNdt(6)=1/8*(1+kesi)*(1-yita);
 dNdt(7)=1/8*(1+kesi)*(1+yita);
 dNdt(8)=1/8*(1-kesi)*(1+yita);
 
 

 
 
 