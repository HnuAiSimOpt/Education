function [gcoord,nodes,bcdof,bcdofa,ff,nnode,nel,sdof,mass_dof]=init_data(ndof)
fid=fopen('rod1.5.bdf','r');
mass_dof=[];  bcdof=[];  bcdofa=[];
if fid~=-1
    nocount=0;
    elcount=0;
    focount=0;
    spccount=0;
    tline =fgetl(fid);
    while 1
        stline=sscanf(tline,'%s');
        if size(stline)>0
            if tline(1)~='$'
              
            if strmatch('GRID',tline)==1
                 nocount=nocount+1;
                 if tline(25)==' '
                        if tline(26)==' '
                            if tline(33)==' '
                                if tline(34)==' '
                                    notem=sscanf(tline,'%*s %8d %6f %6f %8f');
                                else
                                    notem=sscanf(tline,'%*s %8d %6f %7f %8f');
                                end
                            else
                                notem=sscanf(tline,'%*s %8d %6f %8f %8f');
                            end
                        else
                            if tline(33)==' '
                                if tline(34)==' '
                                    notem=sscanf(tline,'%*s %8d %7f %6f %8f');
                                else
                                    notem=sscanf(tline,'%*s %8d %7f %7f %8f');
                                end
                            else
                                notem=sscanf(tline,'%*s %8d %7f %8f %8f');
                            end
                        end
                    else
                        if tline(33)==' '
                            if tline(34)==' '
                                notem=sscanf(tline,'%*s %8d %8f %6f %8f');
                            else
                                notem=sscanf(tline,'%*s %8d %8f %7f %8f');
                            end
                        else
                            notem=sscanf(tline,'%*s %8d %8f %8f %8f');
                        end
                    end
                    gcoord(nocount,1:3)=[notem(2) notem(3) notem(4)];
            elseif strmatch('CHEXA',tline)==1
                elcount=elcount+1;
                eltem=sscanf(tline,'%*s %8d %8d %8f %8f %8f %8f %8f %8f');
                nodes(elcount,1:6)=[eltem(3) eltem(4) eltem(5) eltem(6) eltem(7) eltem(8)];
           elseif strmatch('+',tline)==1
             
                eltem=sscanf(tline,'%*s %8f %8f');
                nodes(elcount,7:8)=[eltem(1) eltem(2)];
            elseif strmatch('SPC',tline)==1
                bctem=sscanf(tline,'%*s %8d %8d');
                bcdof=[bcdof;  bctem(2)*ndof-2;  bctem(2)*ndof-1;  bctem(2)*ndof-0];  
                   
            elseif strmatch('SUPORT1',tline)==1
                bctema=sscanf(tline,'%*s %8d %8d');
                bcdofa=[bcdofa;  bctema(2)*ndof-0]; 
          
            elseif strmatch('FORCE',tline)==1
                forcetem=sscanf(tline,'%*s %8d %8d');
                mass_dof=[mass_dof; forcetem(2)*ndof-0]; 
            end          
            end 
          end
         tline =fgetl(fid);
         if tline==-1
             break
         end
    end
    fclose(fid);
else
    disp('input path wrong!');
end
nel=size(nodes,1);
nnode=size(gcoord,1);
sdof=ndof*nnode;        
ff=sparse(sdof,sdof);
gcoord=0.001*gcoord;

clear C1 C2 C3