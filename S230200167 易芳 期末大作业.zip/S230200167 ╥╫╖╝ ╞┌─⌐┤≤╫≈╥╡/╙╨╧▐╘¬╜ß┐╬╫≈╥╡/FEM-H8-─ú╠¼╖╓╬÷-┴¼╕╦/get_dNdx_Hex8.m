function [dNdx,dNdy,dNdz]=get_dNdx_Hex8(nnel,dNdr,dNds,dNdt,inv_jacob)

 for i=1:nnel
 dNdx(i)=inv_jacob(1,1)*dNdr(i)+inv_jacob(1,2)*dNds(i)+inv_jacob(1,3)*dNdt(i);
 dNdy(i)=inv_jacob(2,1)*dNdr(i)+inv_jacob(2,2)*dNds(i)+inv_jacob(2,3)*dNdt(i);
 dNdz(i)=inv_jacob(3,1)*dNdr(i)+inv_jacob(3,2)*dNds(i)+inv_jacob(3,3)*dNdt(i);
 end