clc;
clear;
error=log10([105.545216	32.40381845	8.890153461	5.735726008]);
time=log10([0.067,0.42,11.8,45]);
plot(time,error,'-^b','MarkerSize',6,'linewidth',1.5);hold on;

set(gca,'FontSize',14);
legend('\fontsize{14}\rm\fontname{helvetica}FEM-H8',...
       'Location','North')
ylabel('\fontsize{14}\rm\fontname{Times New Roman}log10(error)')
xlabel('\fontsize{14}\rm\fontname{Times New Roman}log10(t)')