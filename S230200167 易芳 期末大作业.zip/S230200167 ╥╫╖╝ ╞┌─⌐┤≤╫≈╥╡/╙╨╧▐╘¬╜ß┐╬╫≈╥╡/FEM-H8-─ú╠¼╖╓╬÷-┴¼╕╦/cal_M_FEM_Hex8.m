function [M]=cal_M_FEM_Hex8(sdof,nel,nnel,nodes,gcoord,edof,rho,ndof)
M=sparse(sdof,sdof);		% initialization of global stiffness matrix
[point,weight]=get_Gauss_Hex8; % Gauss integration points & weights
for iel=1:nel       %loop for the total number of element
    for i=1:nnel    % loop for 8 nodes of (iel)-th element
        nod(i)=nodes(iel,i);    % extract nodes for (iel)-th element
        xco(i)=gcoord(nod(i),1);   % extract x value of the node
        yco(i)=gcoord(nod(i),2);   % extract y value of the node
        zco(i)=gcoord(nod(i),3);   % extract z value of the node
    end 
    Me=sparse(edof,edof);	   % initialization of element stiffness matrix   
    %---------------------numerical integration---------------------
    for i=1:nnel
        kesi=point(i,1);
        yita=point(i,2);
        zeta=point(i,3);
        [shape,dNdr,dNds,dNdt]=get_shape_Hex8(kesi,yita,zeta); 
        jacob=cal_jacob_Hex8(nnel,dNdr,dNds,dNdt,xco,yco,zco); 
        det_jacob=det(jacob); 
        N=get_N(shape);
        Me=Me+rho*(N'*N)*weight(1)*weight(2)*weight(3)*det_jacob;
%         Me=zeros(24,24);
%         for iii=1:24
%             Me(iii,iii)=1;
%         end;
%         Me=0.2^3*rho/8*Me;
    end
        index = get_eledof(nod,nnel,ndof);    % extract system dofs for the element 
        M(index,index) = M(index,index) + Me; % assemble element stiffness matrices
end