import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize

# 1. 定义问题：HIC值计算模型
def calculate_hic(fire_time, collision_speed, occupant_weight):
    """
    计算头部伤害指数(HIC)
    参数:
    - fire_time: 安全气囊起爆时间(ms)
    - collision_speed: 碰撞速度(km/h)
    - occupant_weight: 乘员体重(kg)
    
    返回:
    - hic: 头部伤害指数，值越小越好
    """
    # 简化模型：HIC值与起爆时间呈二次函数关系，有一个最优值
    # 实际中这会是更复杂的多物理场模型
    base_time = 30 + collision_speed * 0.1 - occupant_weight * 0.05
    # 基础HIC值，与碰撞速度正相关
    base_hic = 500 + collision_speed * 5
    
    # 起爆时间偏离最优时间越多，HIC值越大
    hic = base_hic + 0.5 * (fire_time - base_time) ** 2
    
    # 添加一些随机扰动，模拟真实世界的不确定性
    hic += np.random.normal(0, 10)
    
    return max(0, hic)  # HIC值不能为负

# 2. 定义优化目标函数
def objective_function(fire_time, collision_speed, occupant_weight):
    """目标函数：最小化HIC值"""
    return calculate_hic(fire_time, collision_speed, occupant_weight)

# 3. 使用粒子群优化算法寻找最优起爆时间
class PSOOptimizer:
    def __init__(self, objective_func, bounds, num_particles=30, max_iter=100):
        self.objective_func = objective_func
        self.bounds = bounds  # 变量边界
        self.num_particles = num_particles
        self.max_iter = max_iter
        
        # 初始化粒子
        self.dim = len(bounds)
        self.positions = np.random.uniform(bounds[:, 0], bounds[:, 1], (num_particles, self.dim))
        self.velocities = np.random.uniform(-1, 1, (num_particles, self.dim))
        
        # 个人最优和全局最优
        self.pbest_positions = self.positions.copy()
        self.pbest_values = np.array([float('inf')] * num_particles)
        self.gbest_position = None
        self.gbest_value = float('inf')
        
    def optimize(self, *args):
        """执行优化"""
        for _ in range(self.max_iter):
            # 计算每个粒子的目标函数值
            for i in range(self.num_particles):
                current_value = self.objective_func(self.positions[i][0], *args)
                
                # 更新个人最优
                if current_value < self.pbest_values[i]:
                    self.pbest_values[i] = current_value
                    self.pbest_positions[i] = self.positions[i].copy()
                
                # 更新全局最优
                if current_value < self.gbest_value:
                    self.gbest_value = current_value
                    self.gbest_position = self.positions[i].copy()
            
            # 更新速度和位置
            w = 0.5  # 惯性权重
            c1 = 1   # 认知系数
            c2 = 2   # 社会系数
            
            for i in range(self.num_particles):
                r1 = np.random.rand()
                r2 = np.random.rand()
                
                # 更新速度
                self.velocities[i] = (w * self.velocities[i] +
                                     c1 * r1 * (self.pbest_positions[i] - self.positions[i]) +
                                     c2 * r2 * (self.gbest_position - self.positions[i]))
                
                # 更新位置
                self.positions[i] += self.velocities[i]
                
                # 确保位置在边界内
                for j in range(self.dim):
                    if self.positions[i][j] < self.bounds[j, 0]:
                        self.positions[i][j] = self.bounds[j, 0]
                    elif self.positions[i][j] > self.bounds[j, 1]:
                        self.positions[i][j] = self.bounds[j, 1]
        
        return self.gbest_position[0], self.gbest_value

# 4. 模拟不同场景并可视化结果
def simulate_different_scenarios():
    # 定义不同场景
    scenarios = [
        {"speed": 40, "weight": 60, "label": "低速-轻量乘员"},
        {"speed": 60, "weight": 60, "label": "中速-轻量乘员"},
        {"speed": 80, "weight": 60, "label": "高速-轻量乘员"},
        {"speed": 60, "weight": 90, "label": "中速-重量乘员"},
    ]
    
    # 起爆时间范围：5ms到100ms
    bounds = np.array([[5, 100]])
    
    # 为每个场景找到最优解
    results = []
    for scenario in scenarios:
        optimizer = PSOOptimizer(objective_function, bounds)
        optimal_time, min_hic = optimizer.optimize(scenario["speed"], scenario["weight"])
        results.append({
            "scenario": scenario,
            "optimal_time": optimal_time,
            "min_hic": min_hic
        })
        
        # 绘制HIC值与起爆时间的关系图
        times = np.linspace(5, 100, 100)
        hic_values = [calculate_hic(t, scenario["speed"], scenario["weight"]) for t in times]
        
        plt.figure(figsize=(10, 6))
        plt.plot(times, hic_values, 'b-', label='HIC值')
        plt.scatter(optimal_time, min_hic, color='red', s=100, label=f'最优起爆时间: {optimal_time:.2f}ms')
        plt.xlabel('起爆时间 (ms)')
        plt.ylabel('HIC值')
        plt.title(f'{scenario["label"]} (速度: {scenario["speed"]}km/h, 体重: {scenario["weight"]}kg)')
        plt.grid(True)
        plt.legend()
        plt.show()
    
    # 汇总结果
    print("\n各场景优化结果汇总:")
    print("-" * 70)
    print(f"{'场景':<20} | {'最优起爆时间(ms)':<18} | {'最小HIC值':<10}")
    print("-" * 70)
    for result in results:
        print(f"{result['scenario']['label']:<20} | {result['optimal_time']:<18.2f} | {result['min_hic']:<10.2f}")
    print("-" * 70)

# 执行模拟
if __name__ == "__main__":
    simulate_different_scenarios()
