# -*- coding: utf-8 -*-
import random
import sys
import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from scipy.interpolate import interp1d
from scipy.interpolate import RBFInterpolator
from sklearn.preprocessing import StandardScaler
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.experimental import enable_halving_search_cv  # 这个还不能移除 !!!!!!
from sklearn.model_selection import HalvingGridSearchCV, train_test_split
import matplotlib
matplotlib.use('Agg')
import warnings
warnings.filterwarnings("ignore", message="One or more of the train scores are non-finite.*")
warnings.filterwarnings("ignore", message="One or more of the test scores are non-finite.*")

# 全局变量，用于存储模型
stress_model1 = None
disp_model1 = None
mass_model1 = None
scaler_X1 = None
pca_model1 = None

X_total = None
D_re = None
H_re = None
cross_rate = None
mutate_rate = None

def get_base_dir():
    """获取应用程序的基本目录（开发时是脚本目录，打包后是 exe 所在目录）"""
    if getattr(sys, 'frozen', False):
        # 打包后的情况
        return os.path.dirname(sys.executable)
    else:
        # 开发环境
        return os.path.dirname(os.path.abspath(__file__))


relationship_path = os.path.join(get_base_dir(), "xlsx/01厚度位置.xlsx")
traint_file_path1 = os.path.join(get_base_dir(), "xlsx/01减重孔训练数据.xlsx")



# RBF模型封装
# 1. 封装RBF模型
class CustomRBF(BaseEstimator, RegressorMixin):
    def __init__(self, kernel='thin_plate_spline', smoothing=0.1, epsilon=None):
        self.kernel = kernel
        self.smoothing = smoothing
        self.epsilon = epsilon

    def fit(self, X, y):
        if self.kernel in ['gaussian', 'multiquadric', 'inverse_multiquadric'] and self.epsilon is None:
            self.epsilon = 1.0
        self.model = RBFInterpolator(X, y,
                                     kernel=self.kernel,
                                     smoothing=self.smoothing,
                                     epsilon=self.epsilon)
        return self

    def predict(self, X):
        return self.model(X)


# 2. 修改训练函数
def train_optimized_rbf1(X, y, target_name):
    # 新增特征降维
    pca = PCA(n_components=27)  # 31-1-3 = 27  # 去掉第一列(序号), 去掉后三列(目标)
    X_scaled = StandardScaler().fit_transform(X)  # 先标准化
    X_pca = pca.fit_transform(X_scaled)  # 然后进行PCA降维

    # 修改数据划分
    X_train, X_test, y_train, y_test = train_test_split(
        X_pca, y,  # 使用降维后数据
        test_size=0.2,
        stratify=np.digitize(y, bins=np.quantile(y, [0.3, 0.7])),  # 分层抽样
        random_state=42
    )

    # 扩大后的参数网格
    # 参数网格
    param_grid = {
        'kernel': [
            'gaussian',                 # 高斯核
            'linear',                   # 线性核（相当于斜顶函数）
            'cubic',                    # 三次核
            'quintic',                  # 五次核
            'multiquadric',             # 多重二次曲面核
            'inverse_multiquadric',     # 反多重二次曲面核
            'thin_plate_spline'         # 薄板样条核
        ],
        'smoothing': np.logspace(-2, 4, 30).tolist(),
        'epsilon': np.concatenate([
            np.linspace(0.01, 2, 20),
            [None]
        ]).tolist()
    }

    # 使用带早停的网格搜索
    grid = HalvingGridSearchCV(
        CustomRBF(),
        param_grid,
        factor=2,  # 降低淘汰率
        min_resources="exhaust",  # 自动确定初始资源
        cv=5,
        scoring='neg_mean_squared_error',  # 改用更稳定指标
        aggressive_elimination=False,  # 关闭激进淘汰
        n_jobs=1
    )

    grid.fit(X_train, y_train)

    # 评估
    best_model = grid.best_estimator_
    y_pred = best_model.predict(X_test)

    return best_model, {'最优参数': grid.best_params_, 'R²': r2_score(y_test, y_pred),
                        'MSE': mean_squared_error(y_test, y_pred), 'MAE': mean_absolute_error(y_test, y_pred)}


# 初始化模型
def init_models1():
    global stress_model1, disp_model1, mass_model1, scaler_X1

    if stress_model1 is not None:
        return  # 已经初始化

    print("初始化模型...")

    # 读取数据
    file_path = traint_file_path1
    try:
        df = pd.read_excel(file_path, sheet_name='Sheet1')
    except Exception as e:
        print(f"读取数据文件失败: {str(e)}")
        # 创建示例数据
        data = {
            '特征1': np.random.rand(100),
            '特征2': np.random.rand(100),
            '特征3': np.random.rand(100),
            '应力': np.random.uniform(100, 500, 100),
            '位移': np.random.uniform(0.1, 5.0, 100),
            '质量': np.random.uniform(1.0, 10.0, 100)
        }
        df = pd.DataFrame(data)
        print("使用示例数据替代")

    # 数据预处理
    df = df.drop_duplicates()
    if '应力' in df.columns:
        df = df[df['应力'] < 1e4]

    # 特征/目标分离
    X = df.iloc[:, 1:-3].values  # 去掉第一列(序号), 去掉后三列(目标)
    y_stress = df['应力'].values if '应力' in df.columns else np.random.uniform(100, 500, len(X))
    y_disp = df['位移'].values if '位移' in df.columns else np.random.uniform(0.1, 5.0, len(X))
    y_mass = df['质量'].values if '质量' in df.columns else np.random.uniform(1.0, 10.0, len(X))

    # 特征标准化
    scaler_X1 = StandardScaler()
    X_scaled = scaler_X1.fit_transform(X)

    # 训练所有模型（自动搜索最优参数）
    # 训练应力模型
    print("训练应力模型...")
    stress_model1, _ = train_optimized_rbf1(X_scaled, y_stress, "应力")

    # 训练位移模型
    print("训练位移模型...")
    disp_model1, _ = train_optimized_rbf1(X_scaled, y_disp, "位移")

    # 训练质量模型
    print("训练质量模型...")
    mass_model1, _ = train_optimized_rbf1(X_scaled, y_mass, "质量")

    print("模型初始化完成")


# 初始化模型
init_models1()


# 截面约束，x与r的关系
def r_x(File_Path, x_index=0, r_index=1):
    try:
        # 1、从 Excel 文件中读取数据
        df = pd.read_excel(File_Path)
        # 2、提取x,r数据 按索引提取 位置 宽度
        x = df.iloc[:, x_index].values
        r = df.iloc[:, r_index].values
        # 3、构造插值函数
        f = interp1d(x, r, kind='cubic', bounds_error=False, fill_value="extrapolate")
        return f
    except:
        # 如果文件不存在，创建默认插值函数
        print(f"警告: 无法读取约束文件 {File_Path}，使用默认约束")
        return lambda x: 50 - 0.2 * x  # 线性约束函数


# 构建r的约束函数f
f1 = r_x(relationship_path, 0, 1)


# 初始化种群
# 每一个基因组
# (X,D,H)分别代表其范围，格式为[x_min,x_max,f_x]
def gen1(X, D, H):
    x = round(random.uniform(X[0], X[1]), X[2])
    d = round(random.uniform(D[0], f1(x) - 0.3), D[2])  # 由于插值拟合有误差，因此-0.3
    h = round(random.uniform(H[0], H[1]), H[2])
    return x, d, h


#每一个个体，一个个体包含10个基因组
def individual(count=10):
    ind_count = []
    while len(ind_count) < count:
        gen = gen1(X_total[len(ind_count)], D_re, H_re)
        if all(judge(*gen, *j) for j in ind_count):
            ind_count.append(gen)
    return ind_count


# 选择操作
def champ(pop, champ_size=3):
    team_member = random.sample(pop, k=champ_size)
    p, q = team_member[0], team_member[1]
    while p == q:
        team_member = random.sample(pop, k=champ_size)
        p, q = team_member[0], team_member[1]
    if dominates1(p, q):
        return p
    elif dominates1(q, p):
        return q
    else:
        return random.sample([p, q], k=1)[0]


# 交叉
# 单个基因交叉
def cross(a, b, fl):
    rate = random.uniform(0, 1)
    # 随机挑选是否交叉
    if rate >= cross_rate:
        proportion = random.uniform(0, 1)
    else:  # 不发生交叉
        proportion = 1
    return round(a * proportion + b * (1 - proportion), fl)


# 两个个体交叉
def crossover1(parent1, parent2):
    child = []
    for i in range(len(parent1)):
        # 对x，r，h进行交叉操作
        x = cross(parent1[i][0], parent2[i][0], X_total[i][2])
        d = cross(parent1[i][1], parent2[i][1], D_re[2])
        h = cross(parent1[i][2], parent2[i][2], H_re[2])
        while d >= f1(x) - 0.3:
            d = cross(parent1[i][1], parent2[i][1], D_re[2])
        # 创建新的圆
        new_circle = (x, d, h)
        # 检查新圆是否在范围内且不与已有圆相交
        if all(judge(*new_circle, *j) for j in child):
            child.append(new_circle)
        else:
            # 如果不符合条件，重新选择
            return crossover1(parent1, parent2)
    return child


# 变异
def mutate1(individual):
    mutated = []
    i = 0
    while i < 10:
        x_rate = random.random()
        d_rate = random.random()
        h_rate = random.random()
        # 依据概率变异每个参数
        if x_rate <= mutate_rate and d_rate <= mutate_rate:
            x = round(random.uniform(X_total[i][0], X_total[i][1]), X_total[i][2])
            d = round(random.uniform(D_re[0], f1(x) - 0.3), D_re[2])
        elif x_rate >= mutate_rate or d_rate >= mutate_rate:
            x = individual[i][0]
            d = individual[i][1]
        while d >= f1(x) - 0.3:
            d = round(random.uniform(D_re[0], f1(x) - 0.3), D_re[2])
        if h_rate <= mutate_rate:
            h = round(random.uniform(H_re[0], H_re[1]), H_re[2])
        elif h_rate >= mutate_rate:
            h = individual[i][2]

        # 创建新的变异圆
        new_circle = (x, d, h)

        # 检查新圆是否在范围内且不与已有圆相交
        if all(judge(*new_circle, *j) for j in mutated):
            mutated.append(new_circle)
            i += 1
    return mutated


# 非支配排序
def non_dominated_sorting1(population):
    fitness_values = [fitnesses(individ) for individ in population]
    # 初始化
    population_size = len(population)
    domination_count = [0] * population_size  # 被支配的次数
    dominated_sets = [[] for _ in range(population_size)] # 支配其他个体的集合
    ranks = [0] * population_size # 每个个体的等级
    fronts = [[]]  # Pareto fronts，初始为空
    # 比较每对个体，确定支配关系
    for p in range(population_size):
        for q in range(population_size):
            if p == q:  # 跳过自身
                continue
            # 检查是否支配
            if dominates1(fitness_values[p], fitness_values[q]):
                dominated_sets[p].append(q)  # p 支配 q
            elif dominates1(fitness_values[q], fitness_values[p]):
                domination_count[p] += 1  # p 被 q 支配

        # 如果 p 没有被任何个体支配，则属于第 0 前沿
        if domination_count[p] == 0:
            ranks[p] = 0
            fronts[0].append(p)

    # 构建剩余前沿
    i = 0
    while len(fronts[i]) > 0:
        next_front = []
        for p in fronts[i]:
            for q in dominated_sets[p]:
                domination_count[q] -= 1
                if domination_count[q] == 0:  # 如果 q 不再被支配
                    ranks[q] = i + 1
                    next_front.append(q)
        i += 1
        fronts.append(next_front)
    # 移除最后一个空前沿
    fronts.pop()
    # 将标号转化成元素
    result = []
    for i in fronts:
        front = []
        for j in i:
            front.append(population[j])
        result.append(front)
    return result


# 支配关系判断
def dominates1(ind1, ind2):
    return all(x <= y for x, y in zip(ind1, ind2)) and any(x < y for x, y in zip(ind1, ind2))


# 拥挤度计算及排序
def calculate_crowding_distance(front):
    # 获取前沿的长度
    front_size = len(front)
    # 对每个个体进行编号
    num_dict = {i: front[i] for i in range(len(front))}
    # 初始化个体拥挤度为0，这个字典为拥挤度大小字典
    crowd_dict = {i: 0 for i in range(len(front))}
    # 获取目标函数的数量
    num_objectives = len(fitnesses(front[0]))
    # 遍历每个目标函数
    for i in range(num_objectives):
        # 列表排序
        sorted_front = sorted(front, key=lambda ind: fitnesses(ind)[i])
        # 将边界设置为拥挤度最大
        key_inf = [key for key, value in num_dict.items() if value == sorted_front[0] or value == sorted_front[-1]]
        for key in key_inf:
            crowd_dict[key] += float('inf')
        # 获取目标值的最小值和最大值
        min_value = fitnesses(sorted_front[0])[i]
        max_value = fitnesses(sorted_front[-1])[i]
        # 避免除0
        if max_value - min_value == 0:
            l2 = 1
        else:
            l2 = max_value - min_value
        # 计算中间的拥挤度并添加进字典
        for j in range(1, front_size - 1):
            key_j = [key for key, value in num_dict.items() if value == sorted_front[0] or value == sorted_front[j]]
            for key in key_j:
                crowd_dict[key] += (fitnesses(sorted_front[j + 1])[i] - fitnesses(sorted_front[j - 1])[i]) / (l2)
    # 将拥挤度字典按照值降序输出键，并寻找对应位置的元素
    sorted_crowd_keys = sorted(crowd_dict, key=crowd_dict.get, reverse=True)
    crowding_front = []
    for i in sorted_crowd_keys:
        crowding_front.append(front[i])
    return crowding_front


# 其他约束函数
# 一个个体中任意两圆不可相交，true表示满足
def judge(x1, r1, h1, x2, r2, h2):
    return abs(x1 - x2) > (r1 + r2)


# 目标函数
def fitnesses(individual1):
    global stress_model1, disp_model1, mass_model1, scaler_X1, pca_model1

    individual2 = np.array(individual1).flatten()

    # 标准化数据
    if scaler_X1 is None:
        # 如果标准化器未初始化，使用随机值
        return (
            random.uniform(100, 500),
            random.uniform(0.1, 5.0),
            random.uniform(1.0, 10.0)
        )

    try:
        # 确保输入是二维数组
        x_scaled = scaler_X1.transform([individual2])  # 标准化输入数据

        # 应用PCA降维
        if pca_model1:
            x_pca = pca_model1.transform(x_scaled)
        else:
            x_pca = x_scaled
    except:
        # 如果转换失败，使用随机值
        return (
            random.uniform(100, 500),
            random.uniform(0.1, 5.0),
            random.uniform(1.0, 10.0)
        )

    # 预测值
    stress_pre = stress_model1.predict(x_pca)[0] if stress_model1 else random.uniform(100, 500)
    disp_pre = disp_model1.predict(x_pca)[0] if disp_model1 else random.uniform(0.1, 5.0)
    mass_pre = mass_model1.predict(x_pca)[0] if mass_model1 else random.uniform(1.0, 10.0)

    return stress_pre, disp_pre, mass_pre


# 目标函数2
def fitnesses_result(individual1):
    global stress_model1, disp_model1, mass_model1, scaler_X1, pca_model1

    try:
        individual2 = np.array(individual1).flatten()

        # 自动截取到正确的特征数量
        expected_features = scaler_X1.n_features_in_
        if len(individual2) > expected_features:
            # print(f"警告：截取特征（{len(individual2)} -> {expected_features}）")
            individual2 = individual2[:expected_features]
        elif len(individual2) < expected_features:
            raise ValueError("特征数量不足！")

        # 标准化数据
        x_scaled = scaler_X1.transform([individual2])
        if pca_model1:
            x_pca = pca_model1.transform(x_scaled)
        else:
            x_pca = x_scaled
        # 预测值
        stress_pre = stress_model1.predict(x_pca)[0]
        disp_pre = disp_model1.predict(x_pca)[0]
        mass_pre = mass_model1.predict(x_pca)[0]

        return stress_pre, disp_pre, mass_pre

        # target = []
        # target.append(stress_pre)   # 对应应力的预测
        # target.append(disp_pre)     # 对应位移的预测
        # target.append(mass_pre)     # 对应质量的预测
    except Exception as e:

        print(f"预测错误: {str(e)}")
        return 0, 0, 0

# 可视化函数
def draw_pic(population, gen, output_dir="results"):
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)

    plt.rcParams['font.sans-serif'] = ['SimHei']  # 指定默认字体为SimHei（黑体）
    plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

    if not population:
        return None

    try:
        # 直接使用population中的个体计算适应度
        fitness_values = [fitnesses_result(ind) for ind in population]

        # 提取三维坐标数据
        stresses = [ind[0] for ind in fitness_values]  # X轴：应力(MPa)
        displacements = [ind[1] for ind in fitness_values]  # Y轴：位移(mm)
        masses = [ind[2] for ind in fitness_values]  # Z轴：质量(kg)

        # 获取最大最小值
        x_min, x_max = np.min(stresses), np.max(stresses)
        y_min, y_max = np.min(displacements), np.max(displacements)

        # 创建三维图
        fig = plt.figure(figsize=(10, 8))
        ax = fig.add_subplot(111, projection='3d')

        ax.xaxis.pane.fill = False  # 清除坐标面填充色
        ax.yaxis.pane.fill = False
        ax.zaxis.pane.fill = False

        #  绘制固定平面作为参考
        x_margin = (x_max - x_min) * 0.05
        y_margin = (y_max - y_min) * 0.05
        x_range = np.linspace(x_min - x_margin,
                              x_max + x_margin, 50)
        y_range = np.linspace(y_min - y_margin,
                              y_max + y_margin, 50)
        # 生成平面
        X, Y = np.meshgrid(x_range, y_range)
        Z = np.full_like(X, 2.50)

        ax.plot_surface(X, Y, Z,
                        alpha=0.2,
                        color='skyblue',
                        edgecolor='none',
                        linewidth=0.3,
                        zorder=1)

        # 绘制散点图
        scatter = ax.scatter(
            stresses,
            displacements,
            masses,
            c=masses,           # 用质量作为颜色维度
            cmap='viridis',
            s=80,               # 点大小
            alpha=0.9,
            edgecolors='w',     # 添加黑色边框
            linewidths=0.8,
            depthshade=False
        )

        # 添加坐标轴标签
        ax.set_xlabel('Stress (MPa)', fontsize=12, labelpad=10)
        ax.set_ylabel('Displacement (mm)', fontsize=12, labelpad=10)
        ax.set_zlabel('Mass (kg)', fontsize=12, labelpad=10)
        ax.set_title(
            f'第{gen}代多目标优化结果\nStress-Displacement-Mass分布',  # 使用\n换行
            fontsize=16,
            pad=0,  # 调整标题与图的间距
            fontfamily='SimHei',  # 显式指定中文字体
            verticalalignment='bottom'  # 标题对齐方式
        )
        # 添加颜色条
        cbar = plt.colorbar(scatter,
                            pad=0.1,
                            shrink=0.6,
                            aspect=20
                            )
        cbar.set_label('Mass (kg)', fontsize=12)
        # 设置视角
        ax.view_init(elev=12, azim=35)  # 仰角12度，方位角35度
        plt.rcParams['path.simplify'] = False
        plt.rcParams['path.snap'] = True
        plt.rcParams.update({
            'font.size': 12,
            'axes.titlesize': 14,
            'axes.labelsize': 12,
            'xtick.labelsize': 10,
            'ytick.labelsize': 10,
            'legend.fontsize': 10
        })
        # 显示图形
        plt.tight_layout()

        # 保存图片
        image_path = os.path.join(output_dir, f'第{gen}代.png')
        plt.savefig(image_path, dpi=300, bbox_inches='tight')
        plt.close()  # 关闭图形以释放内存

        return image_path
    except Exception as e:
        print(f"绘制图片失败: {str(e)}")
        return None


# 保存数据到Excel
def write_data(population, gen, output_dir="results"):
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)

    if not population:
        return None

    try:
        # 转换数据
        data = []
        for i, ind in enumerate(population):
            data.append({
                "个体ID": i + 1,
                "应力(MPa)": ind[0],
                "位移(mm)": ind[1],
                "质量(kg)": ind[2]
            })

        # 创建DataFrame
        df = pd.DataFrame(data)

        # 保存到Excel
        excel_path = os.path.join(output_dir, f'第{gen}代优化结果.xlsx')
        df.to_excel(excel_path, index=False)

        return excel_path
    except Exception as e:
        print(f"保存Excel失败: {str(e)}")
        return None


# 在非支配排序后添加加权评估函数
def weighted_score1(individual, stress_weight, mass_weight, disp_weight):
    stress, disp, mass = fitnesses_result(individual)
    # 由于应力、位移和质量都是越小越好，我们使用加权和
    # 注意：这里假设所有目标都是最小化目标
    return stress_weight * stress + disp_weight * disp + mass_weight * mass

# 主运行函数
def run_algorithm1(pop_size=300, generation=100, cross_rate_input=0.7, mutate_rate_input=0.3,
                  stress_weight=0.4, mass_weight=0.3, disp_weight=0.3, running=None):
    global X_total, D_re, H_re, cross_rate, mutate_rate, traint_file_path1, relationship_path

    # 初始化 running 标志，如果未提供则始终为 True
    if running is None:
        running = [True]  # 使用列表以便在函数内部修改

    cross_rate = cross_rate_input
    mutate_rate = mutate_rate_input

    # 定义列表，x的范围
    X1 = [0, 10, 2]
    X2 = [10, 30, 2]
    X3 = [30, 50, 2]
    X4 = [50, 70, 2]
    X5 = [70, 90, 2]
    X6 = [90, 110, 2]
    X7 = [110, 130, 2]
    X8 = [130, 150, 2]
    X9 = [150, 170, 2]
    X10 = [170, 190, 2]
    X_total = [X1, X2, X3, X4, X5, X6, X7, X8, X9, X10]  # x的约束范围
    D_re = [0, 0, 2]  # d的约束范围，最大值是f(x)-0.3,这里标为0，不使用
    H_re = [0, 160, 0]  # H的约束范围

    # 创建输出目录
    output_dir = os.path.join(get_base_dir(), "results1")
    os.makedirs(output_dir, exist_ok=True)

    # 初始化种群
    pop = [individual() for _ in range(pop_size)]

    # 存储每一代的最佳个体（基于权重）
    best_solution = None
    best_score = float('inf')

    # 主循环
    for gen in range(generation):
        # 检查是否被中止
        if not running[0]:
            print(f"算法在第 {gen} 代被中止")
            # 即使中止也要保存当前结果
            image_path = draw_pic(pop, gen, output_dir)
            excel_path = write_data(pop, gen, output_dir)
            break

        print(f"Generation {gen + 1}/{generation}")

        new_child = []

        # 选择、交叉、变异
        for _ in range(pop_size // 2):
            # 再次检查是否被中止
            if not running[0]:
                break

            parent1 = champ(pop)
            parent2 = champ(pop)
            while parent1 == parent2:
                parent2 = champ(pop)

            child1 = crossover1(parent1, parent2)
            child2 = crossover1(parent2, parent1)

            mutated_child1 = mutate1(child1)
            mutated_child2 = mutate1(child2)

            new_child.append(mutated_child1)
            new_child.append(mutated_child2)

        # 再次检查是否被中止
        if not running[0]:
            # 即使中止也要保存当前结果
            image_path = draw_pic(pop, gen, output_dir)
            excel_path = write_data(pop, gen, output_dir)
            break

        # 合并种群
        pop_child = pop + new_child

        # 非支配排序
        pop_child_fronts = non_dominated_sorting1(pop_child)

        # 构建新一代种群
        new_pop = []
        for front in pop_child_fronts:
            if len(new_pop) + len(front) <= pop_size:
                new_pop += front
            else:
                new_count = pop_size - len(new_pop)
                new_front = calculate_crowding_distance(front)
                new_pop += new_front[:new_count]
                break

        pop = new_pop

        # 使用权重评估当前种群
        current_best = None
        current_best_score = float('inf')
        for ind in pop:
            # 再次检查是否被中止
            if not running[0]:
                break

            score = weighted_score1(ind, stress_weight, mass_weight, disp_weight)
            if score < current_best_score:
                current_best = ind
                current_best_score = score

        # 更新全局最佳
        if current_best_score < best_score:
            best_solution = current_best
            best_score = current_best_score

        if gen % 10 == 0 or gen == generation - 1:
        # if gen == 10 or gen == 100 or gen == 500 or gen == 1000 or gen == 3000 or gen == 5000 or gen == 8000 or gen == 9999 or gen == generation - 1:

            # 计算每个个体的适应度
            #fitness_values = [fitnesses(ind) for ind in pop]

            # 绘制并保存图片
            image_path = draw_pic(pop, gen, output_dir)

            # 保存数据到Excel
            excel_path = write_data(pop, gen, output_dir)

    # 保存最终的最佳解
    if best_solution is not None:
        final_stress, final_disp, final_mass = fitnesses_result(best_solution)
        final_score = weighted_score1(best_solution, stress_weight, mass_weight, disp_weight)

        print(f"\n最终最佳解:")
        print(f"应力: {final_stress:.4f} MPa")
        print(f"位移: {final_disp:.4f} mm")
        print(f"质量: {final_mass:.4f} kg")
        print(f"加权得分: {final_score:.4f}")

        # 保存最佳解到文件
        best_solution_path = os.path.join(output_dir, "最佳解.txt")
        with open(best_solution_path, "w", encoding="utf-8") as f:
            f.write(f"权重配置: 应力={stress_weight}, 位移={disp_weight}, 质量={mass_weight}\n")
            f.write(f"应力: {final_stress:.4f} MPa\n")
            f.write(f"位移: {final_disp:.4f} mm\n")
            f.write(f"质量: {final_mass:.4f} kg\n")
            f.write(f"加权得分: {final_score:.4f}\n\n")
            f.write("基因组详情:\n")
            for i, (x, d, h) in enumerate(best_solution):
                f.write(f"基因组 {i + 1}: x={x:.2f}, d={d:.2f}, h={h:.2f}\n")

        print(f"最佳解已保存到: {best_solution_path}")

        # 绘制最佳解的示意图
        plt.figure(figsize=(10, 6))
        positions = [gene[0] for gene in best_solution]
        diameters = [gene[1] for gene in best_solution]

        plt.scatter(positions, [0] * len(positions), s=[d * 100 for d in diameters], alpha=0.6)
        plt.title("最佳解的孔洞分布", fontsize=14, fontfamily='SimHei')
        plt.xlabel("位置 (mm)", fontsize=12)
        plt.ylabel("直径 (放大显示)", fontsize=12)
        plt.grid(True, linestyle='--', alpha=0.7)

        best_image_path = os.path.join(output_dir, "最佳解分布.png")
        plt.savefig(best_image_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"最佳解分布图已保存到: {best_image_path}")


    # 返回最后一次的结果
    return image_path, excel_path


if __name__ == "__main__":
    # 测试运行
    image_path, excel_path = run_algorithm1()
    print(f"图片保存路径: {image_path}")
    print(f"Excel保存路径: {excel_path}")