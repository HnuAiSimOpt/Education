import numpy as np
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import random
import keras
import tensorflow.keras as keras
import tensorflow.keras.layers as layers
from datetime import datetime
from keras.models import *
from keras.layers import *
from keras.optimizers import *
import scipy.io as scio
import csv
import xlrd
import pandas as pd
import os
from scipy.io import loadmat
import tensorflow as tf
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from keras.utils import plot_model
# from keras.utils.vis_utils import plot_model
from fun_spectrogram import combine_valid_test
from fun_spectrogram import report_to_array

import os
from fun_spectrogram import find_even_odd

'''data1=scio.loadmat(os.path.join(d_path,files[i]))'''


# %% 构造模型
class CustomModelCheckpoint(keras.callbacks.Callback):
    def __init__(self, model, path):
        self.model = model
        self.path = path
        self.best_loss = np.inf

    def on_epoch_end(self, epoch, logs=None):
        val_loss = logs['val_loss']
        if val_loss < self.best_loss:
            print("\nValidation loss decreased from {} to {}, saving model".format(self.best_loss, val_loss))
            self.model.save_weights(self.path, overwrite=True)
            self.best_loss = val_loss


# 4传感器
def mymodel(classfication_num):
    inputs = keras.Input(shape=(train_x.shape[1], train_x.shape[2], train_x.shape[3]))

    h1 = layers.Conv2D(filters=16, kernel_size=(2, 2), strides=(1, 1), padding='same', activation='relu')(inputs)
    h1 = layers.MaxPool2D(pool_size=(2, 2), strides=(2, 2), padding='same')(h1)
    h1 = layers.Conv2D(filters=32, kernel_size=(2, 2), strides=(1, 1), padding='same', activation='relu')(h1)
    h1 = layers.MaxPool2D(pool_size=(2, 2), strides=(2, 2), padding='same')(h1)
    h1 = layers.Flatten()(h1)
    h1 = layers.Dropout(0.4)(h1)

    # h1 = layers.Dense(32, activation='relu')(h1)
    h1 = layers.Dense(classfication_num, activation='softmax')(h1)

    deep_model = keras.Model(inputs, h1)
    return deep_model


'''def mymodel():
    inputs = keras.Input(shape=(train_x.shape[1], train_x.shape[2], train_x.shape[3]))

    h1 = layers.Conv2D(filters=8, kernel_size=(3, 3), strides=(1, 1), padding='same', activation='relu')(inputs)
    h1 = layers.MaxPool2D(pool_size=(2, 2), strides=(2, 2), padding='same')(h1)
    h1 = layers.Conv2D(filters=16, kernel_size=(3, 3), strides=(1, 1), padding='same', activation='relu')(h1)
    h1 = layers.MaxPool2D(pool_size=(2, 2), strides=(2, 2), padding='same')(h1)
    h1 = layers.Flatten()(h1)
    h1 = layers.Dropout(0.4)(h1)

    h1 = layers.Dense(32, activation='relu')(h1)
    h1 = layers.Dense(9, activation='softmax')(h1)

    deep_model = keras.Model(inputs, h1)
    return deep_model'''


def random_shuffle(train_x, train_y):
    DataIndex = [i for i in range(len(train_y))]
    random.shuffle(DataIndex)
    X = train_x[DataIndex]
    Y = train_y[DataIndex]
    return X, Y


# %% 读取数据定义函数
# filename_combine = ['50', '50high', '50low']
name_combine1 = ['corrcoef', 'IPM']

# fusion_str1 = '25'  # 更换数据来源
fusion_str2 = 'svd3'  # 更换数据来源
tem_name = ['25', '50', '100', '150']
stress_name = ['stress0', 'stress75', 'stress150']

# bandpass_combine = ['15001650', '16501800', '18002047']
lr = 1e-3
weight_decay = 1e-4
num = 3  # 训练次数
epoch = 100  # 轮数
batch_size = 32  # 批数量
i3 = 0
i4 = 0
i5 = 0
find_type = 0  # 1为奇数+normal，2为偶数+normal,0为不变动
for i5 in range(0, len(stress_name)):
    path_root = 'D:/轴承数据/0705数据AL_LW_juzi/different_stress/' + stress_name[i5] + '/'  # 更换数据来源
    path_save = 'D:/轴承数据/0705数据AL_LW_juzi/different_stress/'  # 保存路径
    path_save_root ='_epoch' + str(epoch) + '_bs' + str(batch_size) + '_lr' + str(lr) + '_findtype' + str(find_type)
    for i3 in range(0, len(tem_name)):
        fusion_combine = ['_' + tem_name[i3] + '_' + fusion_str2]
        # path_save = path_root + tem_name[i3] + '/'  # 保存路径

        for i4 in range(0, len(fusion_combine)):
            mat_path = path_root + tem_name[i3] + '/' + 'mat数据/'
            str2 = name_combine1[0]
            str1 = str2 + '_3k5h' + '_fusion' + str(fusion_combine[i4])
            data = scio.loadmat(mat_path + str1 + '.mat')
            train_x0 = data['Train_X_' + str2]
            valid_x0 = data['Valid_X_' + str2]
            test_x0 = data['Test_X_' + str2]
            train_y0 = data['Train_Y']
            valid_y0 = data['Valid_Y']
            test_y0 = data['Test_Y']
            # 1为奇数+normal，2为偶数+normal,0为不变动

            train_x, train_y = find_even_odd(train_x0, train_y0, find_type)
            valid_x, valid_y = find_even_odd(valid_x0, valid_y0, find_type)
            test_x, test_y = find_even_odd(test_x0, test_y0, find_type)
            print(train_x.shape)
            print(valid_x.shape)
            print(test_x.shape)
            print(train_y.shape)
            print(valid_y.shape)
            print(test_y.shape)
            [dim1, dim2, dim3] = np.shape(train_x)
            train_x = tf.reshape(train_x, (np.size(train_x, 0), dim2, dim3, 1))
            valid_x = tf.reshape(valid_x, (np.size(valid_x, 0), dim2, dim3, 1))
            test_x = tf.reshape(test_x, (np.size(test_x, 0), dim2, dim3, 1))

            accuracyAll = 0
            accuracyData = []
            lossAll = 0
            lossData = []
            history_all = []
            ypred_all = []
            startdate = datetime.utcnow()

            combine_all = np.zeros((np.size(test_y, 0), 2 * num + 1))
            combine_all_3 = np.zeros((np.size(test_y, 0), 3 * num + 1))

            path_h5 = path_save + 'h5/' + stress_name[i5]+ '/'+path_save_root + '/' + str1 + '/'
            if not os.path.exists(path_h5):
                os.makedirs(path_h5)
                print("Folder created")
            else:
                print("Folder already exists")

            model_path = path_save + 'model_pic/'+ stress_name[i5]+ '/' + path_save_root + '/' + str1 + '/'
            if not os.path.exists(model_path):
                os.makedirs(model_path)
                print("Folder created")
            else:
                print("Folder already exists")

            for i in range(1, num + 1):
                # 获取当前时间
                classfication_num = max(test_y) + 1
                model = mymodel(classfication_num)
                model.summary()
                if i == 1:
                    plot_model(model, to_file=model_path + str1 + '_model_' + '.png', show_shapes=True, dpi=600)

                model.compile(
                    optimizer=keras.optimizers.Adam(learning_rate=lr, beta_1=0.9, beta_2=0.999, epsilon=1e-8),
                    loss='sparse_categorical_crossentropy',
                    metrics=['accuracy'])
                # learning_rate = 1e-3, beta_1 = 0.9, beta_2 = 0.999, epsilon = 1e-8

                history = model.fit(train_x, train_y,
                                    batch_size=batch_size, epochs=epoch, verbose=1,
                                    validation_data=(test_x, test_y),
                                    callbacks=[CustomModelCheckpoint(
                                        model, path_h5 + str1 + '_' + str(i) + '.h5')])

                model.save(path_h5 + str1 + '_' + str(i) + '.h5')

                # 评估模型
                loss, accuracy = model.evaluate(test_x, test_y, verbose=1)

                history_all.append(np.array(history.history['loss']))
                history_all.append(np.array(history.history['val_loss']))
                history_all.append(np.array(history.history['accuracy']))
                history_all.append(np.array(history.history['val_accuracy']))

                accuracyAll += accuracy
                lossAll += loss
                accuracyData.append(accuracy)
                lossData.append(loss)
                print('第', i, '次训练结果', 'loss:', loss, 'accuracy:', accuracy)
                y_predict = model.predict(test_x)
                y_pred_int = np.argmax(y_predict, axis=1)
                ypred_all.append(np.squeeze(test_y))
                ypred_all.append(y_pred_int)
                # print(y_pred_int[0:5])
                from sklearn.metrics import classification_report

                # report2 = classification_report(test_y, y_pred_int, digits=4)

                report = classification_report(test_y, y_pred_int, digits=4, output_dict=True)
                report_array = report_to_array(report)
                if i == 1:
                    report_all = np.zeros((len(report_array), 4 * num))
                report_all[:, 4 * i - 4:4 * i] = report_array

                hidden_features = model.predict(test_x)  # 就是y_pred
                '''q2=hidden_features.astype(float)
                q3=q2[:,0:17]
                # 超过17列无法识别
                '''

                '''tsne_result = TSNE(n_components=2, random_state=33, verbose=1).fit_transform(hidden_features)
                tsne_result_3 = TSNE(n_components=3, random_state=33, verbose=1).fit_transform(hidden_features)
    
                combine_all[:, 2 * i - 2:2 * i] = tsne_result
                combine_all_3[:, 3 * i - 3:3 * i] = tsne_result_3'''

            overdate = datetime.utcnow()


            def gettime(startdate, overdate):
                hours = overdate.hour - startdate.hour
                mins = overdate.minute - startdate.minute
                seconds = overdate.second - startdate.second
                deltatime = [hours, mins, seconds]
                print('耗费时间为:', deltatime[0], 'h', deltatime[1], 'min', deltatime[2], 's')
                return deltatime


            deltatime = gettime(startdate, overdate)

            A_L_data = []
            A_L_data.append(accuracyData)
            A_L_data.append(lossData)
            A_L_data.append(deltatime)

            np.array(ypred_all)
            history_all = np.array(history_all)
            np.transpose(history_all)
            '''combine_all=np.array(combine_all)
            ap=combine_all.reshape(np.size(combine_all,1),np.size(combine_all,0)*np.size(combine_all,2),order='F')'''

            '''combine_all[:, num * 2:num * 2 + 1] = test_y
            combine_all_3[:, num * 3:num * 3 + 1] = test_y'''

            import os

            d_path = path_save + 'excel数据/'+ stress_name[i5]+ '/' + path_save_root + '/' + str1 + '/'
            if not os.path.exists(d_path):
                os.makedirs(d_path)
                print("Folder created")
            else:
                print("Folder already exists")


            def save_excel(input_data, save_name, root_path, index_judge):
                import pandas as pd
                data = input_data
                df = pd.DataFrame(data)
                save_path = root_path + str(save_name) + '.xlsx'
                # df.to_excel(save_path, index=False)
                df.to_excel(save_path, index=index_judge)


            # index_judge = True 显示标题
            index_judge = False  # 不显示标题
            save_excel(combine_all_3, str1 + '_tsne_dim3', d_path, index_judge)
            save_excel(combine_all, str1 + '_tsne', d_path, index_judge)
            save_excel(history_all, str1 + '_history', d_path, index_judge)
            save_excel(ypred_all, str1 + '_ypred', d_path, index_judge)
            save_excel(A_L_data, str1 + '_ALdata', d_path, index_judge)
            save_excel(report_all, str1 + '_report', d_path, index_judge)

# %%
'''def acc_line():
    # 绘制acc和loss曲线
    acc = history.history['accuracy']
    val_acc = history.history['val_accuracy']
    loss = history.history['loss']
    val_loss = history.history['val_loss']

    epochs = range(len(acc))  # Get number of epochs

    # 画accuracy曲线
    plt.plot(epochs, acc, 'r', linestyle='-.')
    plt.plot(epochs, val_acc, 'b', linestyle='dashdot')
    plt.title('Training and validation accuracy')
    plt.xlabel("Epochs")
    plt.ylabel("Accuracy")
    plt.legend(["Accuracy", "Validation Accuracy"])
    plt.show()
    plt.figure()

    # 画loss曲线
    plt.plot(epochs, loss, 'r', linestyle='-.')
    plt.plot(epochs, val_loss, 'b', linestyle='dashdot')
    plt.title('Training and validation loss')
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.legend(["Loss", "Validation Loss"])
    plt.show()


acc_line()


# 绘制混淆矩阵
def confusion():
    y_pred_gailv = model.predict(test_x, verbose=1)
    y_pred_int = np.argmax(y_pred_gailv, axis=1)
    print(len(y_pred_int))
    con_mat = confusion_matrix(test_y.astype(str), y_pred_int.astype(str))
    print(con_mat)
    coef = np.array(train_y).flatten()
    classes = list(set(coef))
    classes.sort()
    plt.imshow(con_mat, cmap=plt.cm.Blues)
    indices = range(len(con_mat))
    plt.xticks(indices, classes)
    plt.yticks(indices, classes)
    plt.colorbar()
    plt.xlabel('guess')
    plt.ylabel('true')
    for first_index in range(len(con_mat)):
        for second_index in range(len(con_mat[first_index])):
            plt.text(first_index, second_index, con_mat[second_index][first_index], va='center', ha='center')
    plt.show()


confusion()'''
