%% =======================
%  工程优化 - SVR代理模型 + GA优化（并行 + 注释版）
%  数据集: undertray_dataset.xlsx
%  功能: 1) SVR超参数寻优 (并行)
%       2) 性能预测拟合
%       3) 遗传算法优化设计
%       4) 可视化结果，包括每代GA演化轨迹
%       5) SVR拟合效果、残差、优化结果性能对比单独独立绘图
% ========================
clear; clc; rng(1);   % 清空环境和命令行窗口，固定随机种子保证可重复性

%% Step1: 读取数据
data = readtable('undertray_dataset.xlsx');   % 从Excel读取数据表格

% 输入变量 (设计参数)
X = [data.t_single, data.is_multilay, data.has_foam, ...
     data.stiff_mode, data.mat_id];           
% 输出变量：最大应力、最大位移
Y_sigma = data.sigma_max;      
Y_delta = data.delta_max;      

%% Step2: 数据标准化 (均值为0，标准差为1)
[Xn, Xmu, Xsigma] = zscore(X); % 标准化X，并保存均值和标准差，用于后续预测

%% Step3: SVR 超参数寻优 (并行 + 交叉验证)
disp('开始超参数寻优...');

% 搜索范围
C_range = logspace(-1,3,5);          % 惩罚参数 C
Eps_range = [1e-5, 1e-4, 1e-3];      % epsilon (误差容忍带)
KernelScale_range = logspace(-2,2,5); % RBF核参数 γ 的倒数

nC = numel(C_range);       % C 的数量
nEps = numel(Eps_range);   % epsilon 的数量
nKs = numel(KernelScale_range); % KernelScale 的数量

nTotal = nC*nEps*nKs;      % 总共组合数
results = zeros(nTotal,4); % 存储 [C, eps, ks, loss]

kfolds = 5;                % 5折交叉验证

% 开启并行池 (如果尚未开启)
if isempty(gcp('nocreate'))
    parpool;  % 使用默认并行池核心数量
end

% 遍历所有参数组合 (使用 parfor 并行)
parfor ii = 1:nTotal
    [iC, iEps, iKs] = ind2sub([nC, nEps, nKs], ii); % 将索引映射到组合
    C = C_range(iC);          % 当前C
    eps = Eps_range(iEps);    % 当前epsilon
    ks = KernelScale_range(iKs); % 当前KernelScale
    
    % 建立SVM回归模型，使用K折交叉验证
    mdl_tmp = fitrsvm(Xn, Y_sigma, ...
        'KernelFunction','rbf', ...
        'BoxConstraint',C, ...
        'Epsilon',eps, ...
        'KernelScale',ks, ...
        'KFold',kfolds);
    
    % 计算交叉验证误差
    loss = kfoldLoss(mdl_tmp);
    
    % 存储结果
    results(ii,:) = [C, eps, ks, loss];
end

% 找到误差最小的超参数组合
[bestMSE, idxBest] = min(results(:,4));
bestParams = results(idxBest,1:3);

fprintf('最优参数: C=%.3f, Epsilon=%.1e, KernelScale=%.3f\n', ...
    bestParams(1),bestParams(2),bestParams(3));
fprintf('对应的交叉验证误差: %.4f\n', bestMSE);

%% Step4: 可视化超参数搜索结果 (C vs KernelScale)
figure;
scatter3(log10(results(:,1)), log10(results(:,3)), results(:,4), ...
    60, results(:,4), 'filled'); % 三维散点图
xlabel('log10(C)'); ylabel('log10(KernelScale)'); zlabel('MSE');
title('SVR 超参数搜索结果'); colorbar;

%% Step5: 使用最优参数重新训练 SVR 模型
mdl_sigma = fitrsvm(Xn, Y_sigma, ...
    'KernelFunction','rbf', ...
    'BoxConstraint',bestParams(1), ...
    'Epsilon',bestParams(2), ...
    'KernelScale',bestParams(3), ...
    'Standardize',true);

mdl_delta = fitrsvm(Xn, Y_delta, ...
    'KernelFunction','rbf', ...
    'BoxConstraint',bestParams(1), ...
    'Epsilon',bestParams(2), ...
    'KernelScale',bestParams(3), ...
    'Standardize',true);

%% Step6: SVR拟合效果可视化 - 单独小图
Ypred_sigma = predict(mdl_sigma,Xn);  
Ypred_delta = predict(mdl_delta,Xn);  

% 1) 最大应力拟合
figure;
scatter(Y_sigma, Ypred_sigma,'b.');
xlabel('真实 σ'); ylabel('预测 σ');
title('SVR 拟合最大应力'); grid on; axis equal;

% 2) 最大位移拟合
figure;
scatter(Y_delta*1e3, Ypred_delta*1e3,'r.');
xlabel('真实 δ (mm)'); ylabel('预测 δ (mm)');
title('SVR 拟合最大位移'); grid on; axis equal;

% 3) 应力残差直方图
figure;
histogram(Y_sigma-Ypred_sigma,30);
xlabel('残差 σ'); ylabel('频数'); title('残差分布 - 应力');

% 4) 位移残差直方图
figure;
histogram(Y_delta-Ypred_delta,30);
xlabel('残差 δ'); ylabel('频数'); title('残差分布 - 位移');

%% Step7: GA优化设计
lb = [0.002, 0, 0, 0, 1];  % 下界
ub = [0.006, 1, 1, 2, 5];  % 上界
int_idx = [2,3,4,5];       % 整数变量索引

objFun = @(x) x(1) + 0.001*x(2) + 0.0005*x(3) + 0.0002*x(4); % 目标函数（示例）

sigma_allow = 260e6;   
delta_allow = 0.002;   
nonlcon = @(x) myConstraints(x,mdl_sigma,mdl_delta,Xmu,Xsigma,sigma_allow,delta_allow);

% 自定义OutputFcn记录每代种群
global popHistory
popHistory = {}; % 用于保存每代种群
function [state,options,optchanged] = recordPopulation(options,state,flag)
    global popHistory
    if strcmp(flag,'iter')
        popHistory{end+1} = state.Population; % 保存每代种群
    end
    state = state; options = options; optchanged = false;
end

opts = optimoptions('ga','PopulationSize',50,'MaxGenerations',30,...
    'Display','iter','PlotFcn',{@gaplotbestf},...
    'OutputFcn',@recordPopulation);

[x_opt,fval,~,output,~,~] = ga(objFun,5,[],[],[],[],lb,ub,[],int_idx,opts);

%% Step8: 输出优化结果
fprintf('\n最优设计解:\n');
fprintf(' 厚度 = %.3f m\n', x_opt(1));
fprintf(' 是否多层 = %d\n', round(x_opt(2)));
fprintf(' 是否泡沫 = %d\n', round(x_opt(3)));
fprintf(' 筋条模式 = %d\n', round(x_opt(4)));
fprintf(' 材料编号 = %d\n', round(x_opt(5)));

xn_opt = (x_opt - Xmu)./Xsigma;
sigma_pred = predict(mdl_sigma,xn_opt);
delta_pred = predict(mdl_delta,xn_opt);

fprintf(' 预测应力 = %.2e Pa\n', sigma_pred);
fprintf(' 预测位移 = %.3e m\n', delta_pred);

%% Step9: 结果对比表格输出
T_result = table(x_opt(1),round(x_opt(2)),round(x_opt(3)),round(x_opt(4)),...
    round(x_opt(5)),sigma_pred,delta_pred,fval, ...
    'VariableNames',{'t_single','is_multilay','has_foam','stiff_mode','mat_id',...
    'sigma_pred','delta_pred','objective'});
writetable(T_result,'opt_result.xlsx');
disp('优化结果已保存到 opt_result.xlsx');

%% Step10: 可视化 - 优化性能指标对比（单独图）
figure;
bar(sigma_pred);
xlabel('应力 (Pa)'); ylabel('数值');
title('优化结果性能指标 - 应力');

figure;
bar(delta_pred*1e3);
xlabel('位移 (mm)'); ylabel('数值');
title('优化结果性能指标 - 位移');

%% Step11: 可视化 - GA演化轨迹 (σ–δ 平面)
figure; hold on;
colors = jet(length(popHistory)); % 用颜色表示代数
for gen = 1:length(popHistory)
    pop_gen = popHistory{gen};                % 获取每代种群
    Xn_pop = (pop_gen - Xmu)./Xsigma;        % 标准化
    sigma_all = predict(mdl_sigma,Xn_pop);   % 应力预测
    delta_all = predict(mdl_delta,Xn_pop);   % 位移预测
    scatter(sigma_all, delta_all*1e3, 20, colors(gen,:), 'filled'); % 绘制每代点
end
xlabel('最大应力 (Pa)'); ylabel('最大位移 (mm)');
title('GA 演化轨迹 (σ–δ 平面)');
colorbar; grid on; hold off;

%% ========== 函数定义 ==========
function [c,ceq] = myConstraints(x,mdl_sigma,mdl_delta,Xmu,Xsigma,sigma_allow,delta_allow)
    xn = (x - Xmu)./Xsigma;                       % 标准化输入
    sigma_pred = predict(mdl_sigma,xn);           % 预测应力
    delta_pred = predict(mdl_delta,xn);           % 预测位移
    c = [sigma_pred - sigma_allow; delta_pred - delta_allow]; % 非线性约束
    ceq = [];
end
