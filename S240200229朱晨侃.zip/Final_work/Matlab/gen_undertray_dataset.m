%% ===============================
% 新能源汽车底护板 - 数据集生成与导出 (>1000条)
% 修改后版本：夹层板应力计算直接使用等效 EI，单位合理
% Author: 你的姓名/学号
% ===============================
clear; clc; rng(42);  % 清空环境并固定随机种子，保证可重复

%% -------------------- 可调参数区 --------------------
N = 2000;                     % 样本数量
L = 1.2;                      % 护板长度 (m)
W = 0.8;                      % 护板宽度 (m)
beff = min(W, L/4);           % 等效梁宽 (m)，假设梁化简宽度
q = 3000;                     % 均布面载 N/m²
F = 1500;                     % 中心集中力 N
sigma_allow = 260e6;          % 允许弯曲正应力 Pa
delta_allow = 0.002;          % 允许挠度 m (2 mm)

% 材料库（可按需增删）
matDB = struct( ...
  'id',   {1,2,3,4,5}, ...
  'name', {'Al6061','Al7075','Q235','CFRP','MgAZ31'}, ...
  'E',    {68e9, 72e9, 200e9, 120e9, 45e9}, ...       % 弹性模量 Pa
  'nu',   {0.33, 0.33, 0.30, 0.28, 0.35}, ...
  'rho',  {2700, 2810, 7850, 1600, 1780});            % 密度 kg/m^3

% 泡沫芯材（夹层时可选）
foam.E   = 1.5e9;     % 弹性模量 Pa
foam.nu  = 0.30;      % 泊松比
foam.rho = 900;       % 密度 kg/m^3

% 加强筋等效刚度增益
% 0=无; 1=单向; 2=网格
k_stiff_map = [1.00, 1.30, 1.60];

% 单层/夹层厚度范围
t_min = 0.001; t_max = 0.006;        % 单层厚度 1~6 mm
tf_min = 0.0008; tf_max = 0.0020;    % 夹层面板厚 0.8~2.0 mm
tc_min = 0.006;  tc_max = 0.020;     % 夹层芯厚 6~20 mm

%% -------------------- 采样设计变量 --------------------
mat_id      = randi([1 numel(matDB)], N, 1);         % 随机材料类型
t_single    = t_min + (t_max - t_min)*rand(N,1);     % 单层厚度
is_multilay = randi([0 1], N, 1);                    % 是否多层
has_foam    = randi([0 1], N, 1);                    % 是否含泡沫
stiff_mode  = randi([0 2], N, 1);                    % 加强筋布置：0/1/2

% 夹层厚度参数（当 is_multilay==1 时有效）
tf_top  = tf_min + (tf_max - tf_min)*rand(N,1);  
tf_bot  = tf_min + (tf_max - tf_min)*rand(N,1);
tc      = tc_min + (tc_max - tc_min)*rand(N,1);

%% -------------------- 计算函数 --------------------
% 计算等效弯曲刚度和密度
function [EI_eq, rho_eq, t_eq] = eq_EI_and_rho(beff, mat, is_multi, has_foam, tf_top, tc, tf_bot, t_single, foam)
    % 单层板
    if is_multi == 0
        t = t_single;                     % 单层厚度
        I = beff * t^3 / 12;             % 梁截面二次矩
        EI_eq = mat.E * I;               % 等效弯曲刚度
        rho_eq = mat.rho;                % 等效密度
        t_eq = t;                         % 等效厚度
    else
        % 夹层板：面-芯-面
        E_face = mat.E;                   % 面板弹性模量
        if has_foam == 1
            E_core = foam.E;              % 核心泡沫模量
            rho_core = foam.rho;          % 核心泡沫密度
        else
            E_core = 0.1 * E_face;        % 简化轻芯假设
            rho_core = 0.5 * mat.rho;     % 假设轻芯密度
        end
        % 层厚和模量
        t1 = tf_bot;  E1 = E_face; rho1 = mat.rho;
        t2 = tc;      E2 = E_core; rho2 = rho_core;
        t3 = tf_top;  E3 = E_face; rho3 = mat.rho;
        t_tot = t1 + t2 + t3;             % 总厚度

        % 计算中性轴位置
        A1 = (E1/E_face)*beff*t1; z1c = t1/2;
        A2 = (E2/E_face)*beff*t2; z2c = t1 + t2/2;
        A3 = (E3/E_face)*beff*t3; z3c = t1 + t2 + t3/2;
        zNA = (A1*z1c + A2*z2c + A3*z3c)/(A1+A2+A3);

        % 等效二次矩
        I1 = (E1/E_face)*(beff*t1^3/12 + beff*t1*(zNA-z1c)^2);
        I2 = (E2/E_face)*(beff*t2^3/12 + beff*t2*(zNA-z2c)^2);
        I3 = (E3/E_face)*(beff*t3^3/12 + beff*t3*(zNA-z3c)^2);
        Ieq = I1 + I2 + I3;

        EI_eq = E_face * Ieq;                         % 等效弯曲刚度
        rho_eq = (rho1*t1 + rho2*t2 + rho3*t3)/t_tot; % 等效密度
        t_eq = t_tot;                                  % 等效厚度
    end
end

% 在两类载荷下计算最大应力与挠度（梁化简，夹层板直接用 EI）
function [sigmaA, deltaA, sigmaB, deltaB] = plate_beam_surrogate(L, beff, EIeq, t_eq, q, F)
    % 工况A：均布载
    q_line = q * beff;                    % 将面载转换为线载
    Mmax_A = q_line * L^2 / 8;            % 简支梁中心最大弯矩
    deltaA = 5 * q_line * L^4 / (384 * EIeq); % 中心最大挠度
    c = t_eq/2;                            % 截面最远纤维
    sigmaA = Mmax_A * c / EIeq;           % σ = M*c/EI，夹层板直接用等效 EI

    % 工况B：中心集中力
    Mmax_B = F * L / 4;                    % 简支梁中心集中力最大弯矩
    deltaB = F * L^3 / (48 * EIeq);       % 中心最大挠度
    sigmaB = Mmax_B * c / EIeq;           % σ = M*c/EI
end

%% -------------------- 主循环计算 --------------------
res = table('Size',[N 20], 'VariableTypes', ...
    {'double','string','double','double','double','double','double','double','double', ...
     'double','double','double','double','double','double','double','double','double','double','double'}, ...
    'VariableNames', ...
    {'mat_id','mat_name','t_single','is_multilay','has_foam','stiff_mode','tf_top','tc','tf_bot', ...
     'E_eq','rho_eq','t_eq','sigmaA','deltaA','sigmaB','deltaB','sigma_max','delta_max','sigma_ok','delta_ok'});

for i = 1:N
    m  = matDB(mat_id(i));                     % 当前样本材料
    km = k_stiff_map(stiff_mode(i)+1);        % 获取筋增益

    [EIeq, rhoeq, teq] = eq_EI_and_rho(beff, m, is_multilay(i), has_foam(i), ...
                                       tf_top(i), tc(i), tf_bot(i), t_single(i), foam);
    EIeq = EIeq * km;                          % 加筋增益

    [sigA, dA, sigB, dB] = plate_beam_surrogate(L, beff, EIeq, teq, q, F);

    % 存储结果
    res.mat_id(i)   = m.id;
    res.mat_name(i) = string(m.name);
    res.t_single(i) = t_single(i);
    res.is_multilay(i) = is_multilay(i);
    res.has_foam(i)    = has_foam(i);
    res.stiff_mode(i)  = stiff_mode(i);
    res.tf_top(i)  = tf_top(i);
    res.tc(i)      = tc(i);
    res.tf_bot(i) = tf_bot(i);

    res.E_eq(i)    = EIeq / (teq^3 * beff / 12); % 等效 E 便于代理建模
    res.rho_eq(i)  = rhoeq;
    res.t_eq(i)    = teq;

    res.sigmaA(i)  = sigA;
    res.deltaA(i)  = dA;
    res.sigmaB(i)  = sigB;
    res.deltaB(i)  = dB;

    res.sigma_max(i) = max(sigA, sigB);         % 最大应力
    res.delta_max(i) = max(dA, dB);             % 最大挠度

    res.sigma_ok(i) = double(res.sigma_max(i) <= sigma_allow); % 应力满足
    res.delta_ok(i) = double(res.delta_max(i) <= delta_allow); % 挠度满足
end

%% -------------------- 导出 Excel --------------------
fname = 'undertray_dataset.xlsx';
writetable(res, fname, 'FileType','spreadsheet');      % 导出 Excel
fprintf('数据已导出：%s （共 %d 行）\n', fname, height(res));

%% -------------------- 可选统计 --------------------
ok_rate = mean(res.sigma_ok & res.delta_ok);          % 双约束满足率
fprintf('满足双约束样本占比：%.1f%%\n', ok_rate*100);
