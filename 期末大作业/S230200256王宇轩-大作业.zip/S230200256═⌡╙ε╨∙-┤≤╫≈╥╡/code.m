% 定义系统参数
N = 501; % 弹簧数量
k = 4; % 弹簧的弹性系数 (N/m)
F_ext = 100; % 右端施加的力 (N)

% 初始化刚度矩阵（N+1 x N+1，因为有501个弹簧和502个节点）
K = zeros(N+1, N+1);

% 构建整体刚度矩阵
for i = 1:N
    K(i,i) = K(i,i) + k;
    if i < N
        K(i,i+1) = -k;
        K(i+1,i) = -k;
    end
    K(i+1,i+1) = K(i+1,i+1) + k;
end

% 添加节点的初始载荷向量
F = zeros(N+1, 1);
F(N+1) = F_ext; % 在第N+1个节点（右端）施加外力

% 应用边界条件：前端（左侧）固定，排除第一个元素
K = K(2:end, 2:end);
F = F(2:end);

% 求解位移U
U = K\F;

% 节点位置向量（假设所有节点均匀分布）
nodes = linspace(0, N*l, N+1);

% 画出位移图
figure; % 创建新图表
plot(nodes(2:end), U, 'LineWidth', 2); % 忽略固定的第一个节点
title('\textbf{位移分布}');
xlabel('节点位置 (m)');
ylabel('位移 (m)');
grid on;

% 计算每个弹簧的应力 sigma = -k * (extension)
% 弹簧伸长量是相邻节点的位移差
extension = diff([0; U]); % 包括固定节点0的位移
stress = k * extension;

% 画出应力图
figure; % 创建新图表
plot(1:N, stress, 'r', 'LineWidth', 2);
title('\textbf{应力分布}');
xlabel('弹簧编号');
ylabel('应力 (N/m)');
grid on;