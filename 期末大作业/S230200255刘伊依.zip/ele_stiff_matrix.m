function ke=ele_stiff_matrix(E_ID,Nodes,Elements,E,u,Width)
    ENodes(:,1) = Elements(E_ID,:); 
    iN = size(ENodes,1); 
    ke = zeros(2*iN,2*iN); 
    D=[E/(1-u^2),u*E/(1-u^2),0;
       u*E/(1-u^2),E/(1-u^2),0;
       0,0,E/(2*(1+u))];

    % �����˹���ֵ����� 
kesi_yita=[-1/sqrt(3),-1/sqrt(3);1/sqrt(3),-1/sqrt(3);1/sqrt(3),1/sqrt(3);-1/sqrt(3),1/sqrt(3)];

w=[1,1];ww=[w(1)*w(1),w(2)*w(1),w(1)*w(1),w(1)*w(2)];
    % ��˹���ּ��㵥Ԫ�նȾ��� 
    for i=1:4 
        kesi=kesi_yita(i,1);yita=kesi_yita(i,2);            
        J = Jacobi(E_ID,kesi,yita,Elements,Nodes);             % �ſɱȾ��� 
%         J=Q4_J(kesi,yita,xy);                              
        A=1/det(J)*[ J(2,2),-J(1,2),      0,      0;        
            0,      0,-J(2,1), J(1,1);
            -J(2,1), J(1,1), J(2,2),-J(1,2)];               
        G=Q4_G(kesi,yita);                                  
        B=A*G;                                              
        
        ke=ke+ww(i)*B'*D*B*Width*det(J);  
  
    end 
end