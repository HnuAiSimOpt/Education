function [NodeStrain,NodeStress]=CalculateStrainAndStress2(U,D,Nodes,Elements)
numEle=size(Elements,1);%单元个数
NodeStress=zeros(3,numEle*4);
kesi_yita_Node=[-1,-1;1,-1;1,1;-1,1];
for i=1:numEle
    noindex=Elements(i,:);
    d=zeros(8,1);
    for j=1:4
        d(2*j-1)=U((noindex(j)-1)*2+1);
        d(2*j)=U((noindex(j)-1)*2+2);
    end
    for m=1:4
        kesi=kesi_yita_Node(m,1);
        yita=kesi_yita_Node(m,2);
        J=Jacobi(i,kesi,yita,Elements,Nodes);
        A=1/det(J)*[J(2,2),-J(1,2),0,0;
            0,0,-J(2,1),J(1,1);
            -J(2,1),J(1,1),J(2,2),-J(1,2)];
        G=Q4_G(kesi,yita);
        B=A*G;
        sigma=D*B*d;
        epsilon=B*d;
        NodeStress(1:3,(i-1)*4+m)=sigma;
        NodeStrain(1:3,(i-1)*4+m)=epsilon;
    end
end
         