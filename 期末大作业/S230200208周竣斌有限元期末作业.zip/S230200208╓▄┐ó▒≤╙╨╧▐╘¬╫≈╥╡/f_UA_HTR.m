% clear;clc
function UA_HTR = f_UA_HTR(t5b,t9,p5b,p9,t3,p3,m_CO2a,m_CO2b,m_CO2a_design,m_CO2b_design,step_i)
%  t5a=365.0104;
%  tp=607.8473;
%  p5a=8080.8;
%  p9=8162.43;
%  t3=338.0285;
%  p3=25000;
%  m_CO2a=66.669;
%  m_CO2a=66.669;
%  step_i=10;
h5b=refpropm('H','T',t5b,'P',p5b,'CO2');
h9=refpropm('H','T',t9,'P',p9,'CO2');
h3=refpropm('H','T',t3,'P',p3,'CO2');
delta_Ph=p9*0.01*(m_CO2b/m_CO2b_design)^(7/4)/step_i;
delta_Pc=p3*0.01*(m_CO2a/m_CO2a_design)^(7/4)/step_i;


Q_HTR=m_CO2b*(h9-h5b);
Hh_HTR=zeros(step_i+1,1);Hh_HTR(1,:)=h5b;
Th_HTR=zeros(step_i+1,1);Th_HTR(1,:)=t5b;Tb_HTR=zeros(step_i,1);Ph_HTR(1,:)=p5b;Pb_HTR=zeros(step_i,1);
Hc_HTR=zeros(step_i+1,1);Hc_HTR(1,:)=h3;
Tc_HTR=zeros(step_i+1,1);Tc_HTR(1,:)=t3;Tt_HTR=zeros(step_i,1);Pc_HTR(1,:)=p3;Pt_HTR=zeros(step_i,1);
Ch_HTR=zeros(step_i,1);Cp1_HTR=zeros(step_i,1);DV1_HTR=zeros(step_i,1);k1_HTR=zeros(step_i,1);
Cc_HTR=zeros(step_i,1);Cp2_HTR=zeros(step_i,1);DV2_HTR=zeros(step_i,1);k2_HTR=zeros(step_i,1);
Cmin_HTR=zeros(step_i,1);
Cmax_HTR=zeros(step_i,1);
CR_HTR=zeros(step_i,1);
eff_HTR=zeros(step_i,1);
NTU_HTR=zeros(step_i,1);
UA_HTR_i=zeros(step_i,1);

for w=1:step_i
    %�Ȳ�
    Hh_HTR(w+1,:)=Hh_HTR(w,:)+Q_HTR/step_i/m_CO2b;
    Ph_HTR(w+1,:)=Ph_HTR(w,:)+delta_Ph;
    Pb_HTR(w,:)=(Ph_HTR(w+1,:)+Ph_HTR(w,:))/2;
    Th_HTR(w+1,:)=refpropm('T','P',Ph_HTR(w+1,:),'H',Hh_HTR(w+1,:),'CO2');
    Tb_HTR(w,:)=(Th_HTR(w+1,:)+Th_HTR(w,:))/2;
    [Cp1_HTR(w,:),DV1_HTR(w,:),k1_HTR(w,:)]=refpropm('CVL','T',Tb_HTR(w,:),'P',Pb_HTR(w,:),'CO2');%�����ݡ�����ճ�ȡ�����ϵ��
    %���
    Hc_HTR(w+1,:)=Hc_HTR(w,:)+Q_HTR/step_i/m_CO2a;
    Pc_HTR(w+1,:)=Pc_HTR(w,:)-delta_Pc;
    Pt_HTR(w,:)=(Pc_HTR(w+1,:)+Pc_HTR(w,:))/2;
    Tc_HTR(w+1,:)=refpropm('T','P',Pc_HTR(w+1,:),'H',Hc_HTR(w+1,:),'CO2');
    Tt_HTR(w,:)=(Tc_HTR(w+1,:)+Tc_HTR(w,:))/2;
    [Cp2_HTR(w,:),DV2_HTR(w,:),k2_HTR(w,:)]=refpropm('CVL','T',Tt_HTR(w,:),'P',Pt_HTR(w,:),'CO2');%�����ݡ�����ճ�ȡ�����ϵ��
    
    Ch_HTR(w,:)=Q_HTR/step_i/(Th_HTR(w+1,:)-Th_HTR(w,:));
    Cc_HTR(w,:)=Q_HTR/step_i/(Tc_HTR(w+1,:)-Tc_HTR(w,:));
    Cmin_HTR(w,:)=min(Ch_HTR(w,:),Cc_HTR(w,:));
    Cmax_HTR(w,:)=max(Ch_HTR(w,:),Cc_HTR(w,:));
    CR_HTR(w,:)=Cmin_HTR(w,:)/Cmax_HTR(w,:);
    eff_HTR(w,:)=Q_HTR/step_i/Cmin_HTR(w,:)/(Th_HTR(w+1,:)-Tc_HTR(w,:));
    if CR_HTR(w,:)~=1
        NTU_HTR(w,:)=log((1-eff_HTR(w,:)*CR_HTR(w,:))/(1-eff_HTR(w,:)))/(1-CR_HTR(w,:));
    else
        NTU_HTR(w,:)=eff_HTR(w,:)/(1-eff_HTR(w,:));
    end
    UA_HTR_i(w,:)=NTU_HTR(w,:)*Cmin_HTR(w,:);
end
UA_HTR=sum(UA_HTR_i);