function D = MatrixD()
    E  = 2.1e5 ;  
    mu = 0.3 ;                                         
    D =  (E/(1-mu^2))* [  1  mu   0
              mu   1   0
               0   0  (1-mu)/2] ;
end
