function InitialModel
    global  Node Element Fixed Force 
    %节点坐标
    Node = importdata('Node.txt');
    Node = Node(:,2:3);
    %x、y 横纵坐标
    x = Node(:,1);
    y = Node(:,2);
    %单元编号
    Element = importdata('Ele.txt');
    Element = Element(:,2:end);
    %固定节点
    Fixed=[1 102 152 153 154 155 156 157 158 159 160 161 162 163 164 165 166 167 168 169 170 171 172 173 174 175 176 177 178 179 180 181 182 183 184 185 186 187 188 189 190 191 192 193 194 195 196 197 198 199 200];
    %外部载荷：节点力
    Force=[2	 0.01000000	0.00000000       
          52 0.01000000 0.00000000];  
end