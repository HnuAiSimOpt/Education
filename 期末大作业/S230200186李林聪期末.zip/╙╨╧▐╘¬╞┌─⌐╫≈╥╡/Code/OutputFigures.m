function OutputFigures
    global Node Element Displacement
    [node_number,dummy] = size(Node);
    dx = Displacement(1:2:(2*node_number));
    dy = Displacement(2:2:(2*node_number));
    x = Node(:,1)';
    y = Node(:,2)';
    X = linspace(-1.0,1.0,100);
    Y = linspace(-1.0,1.0,100);
    %x方向位移云图
    figure(1)
    Z = griddata(x,y,dx,X',Y,'v4');
    [C,h]=contourf(X,Y,Z,20);
    text(0.2,-0.4,['max:',num2str(max(dx))],'Color','white');
    title('X-Component of Displacement');
    colorbar
    colormap('jet')
    set(h,'LineColor','none')
    
    %y方向位移云图
    figure(2)
    Z = griddata(x,y,dy,X',Y,'v4');
    [C,h]=contourf(X,Y,Z,20);
    text(0.2,-0.4,['max:',num2str(max(dy))],'Color','black');
    title('Y-Component of Displacement');
    colorbar
    colormap('jet')
    set(h,'LineColor','none')
    %计算应力
    global Stress
    [element_number,dummy] = size( Element) ;
    Stress = zeros(25*element_number,6);
    for ie =1:1:element_number
        node = Element(ie,:);
        x0 = Node(node,1);
        y0 = Node(node,2);
        D = MatrixD();
        Delta = zeros(16,1);
        Delta(1:2:16) = Displacement(node*2-1);
        Delta(2:2:16) = Displacement(node*2);
        w = [-0.9061798459386640, -0.5384693101056830,  0,  0.5384693101056830,   0.9061798459386640] ; 
        for i=1:1:length(w)
            for j=1:1:length(w)
                B = MatrixB( ie, w(i), w(j) ) ;
                N = ShapeFunction( w(i), w(j) ) ;
                x = N * x0;
                y = N * y0;
                stress = D*B*Delta;
                Stress((25*(ie-1)+5*(i-1)+j),1:5)=[x,y,stress'];
            end
        end
    end
    %计算von Mises应力并画出云图
    for i = 1:1:25*element_number
        sigma_1 = Stress(i,3);
        sigma_2 = Stress(i,4);
        sigma_3 = Stress(i,5);
        sigma_max = (sigma_1 + sigma_2)/2 +sqrt(((sigma_1 - sigma_2)/2)^2+sigma_3^2);
        sigma_min = (sigma_1 + sigma_2)/2 -sqrt(((sigma_1 - sigma_2)/2)^2+sigma_3^2);
        Mises = sqrt(((sigma_max-sigma_min)^2+sigma_max^2+sigma_min^2)/2);
        Stress(i,6) = Mises;
    end
    
    figure(4)
    Z = griddata(Stress(:,1),Stress(:,2),Stress(:,6),X',Y,'v4');
    [C,h]=contourf(X,Y,Z,20);
    text(0.2,-0.4,['max:',num2str(max(Stress(:,6)))],'Color','black');
    title('von Mises Stress');
    colorbar
    colormap('jet')
    set(h,'LineColor','none')
end

