function Solve  
    global Node Element Fixed Force KK Displacement
    [node_number,dummy] = size(Node) ;
    [element_number,dummy] = size( Element) ;
    KK = sparse(node_number * 2, node_number * 2);
    %计算刚度矩阵并组装
    for num=1:1:element_number
       k = StiffnessMatrix(num) ;
       Assemble(num, k) ;
    end
    %设置力向量
    gf = zeros( node_number * 2, 1 ) ;
        node = Force(:,1);
        gf((node-1)*2+1) = Force(:,2);
        gf((node-1)*2+2) = Force(:,3);
    %置大数法    
    gf((Fixed*2-1):Fixed*2) = 0;
    KK(((2*Fixed-1)),(2*Fixed-1)) = KK((2*Fixed-1),(2*Fixed-1))*1e15;
    KK(2*Fixed,2*Fixed) = KK(2*Fixed,2*Fixed)*1e15;
%     %置1法
%     KK((2*Fixed-1),:)=0;
%     KK((2*Fixed),:)=0;
%     KK(:,(2*Fixed-1))=0;
%     KK(:,(2*Fixed))=0;
%     KK((2*Fixed-1),(2*Fixed-1))=1;
%     KK((2*Fixed),(2*Fixed))=1;
%     gf(2*Fixed-1)=0;
%     gf(2*Fixed)=0;
    %求解位移
    Displacement = KK \ gf ;
end

