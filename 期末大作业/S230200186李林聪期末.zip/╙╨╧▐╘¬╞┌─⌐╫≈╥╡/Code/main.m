function fem
    clear;clc;close all
    %读取单元、节点等信息，初始化模型
    InitialModel;
    %求总刚，求解位移
    Solve;
    %计算应力，输出位移、应力云图
    OutputFigures;          
end



