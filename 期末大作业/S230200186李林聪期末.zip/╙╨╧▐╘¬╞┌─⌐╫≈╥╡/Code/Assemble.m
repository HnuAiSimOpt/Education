%组装刚度矩阵
function AssembleStiffnessMatrix(num, k)
    global Element KK
    element = Element(num,:);
    n = zeros(1,8*2);
    n(1:2:8*2)=2*element-1;
    n(2:2:8*2)=2*element;
    KK(n,n)=KK(n,n)+k;
end