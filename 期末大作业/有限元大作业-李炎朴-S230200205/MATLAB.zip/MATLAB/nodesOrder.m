function needChange = nodesOrder(xi,yi,xj,yj,xm,ym)
%该函数进行单元节点顺序的判定
%输入单元节点坐标
%计算单元面积，如果为负则需要调换顺序
A = (xi*(yj-ym) + xj*(ym-yi) + xm*(yi-yj))/2;
if A<0
    needChange = 1;
else
    needChange = 0;
end

end