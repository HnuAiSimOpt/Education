function ConTop2D(Macro_struct, Micro_struct, penal, rmin)
%% USER-DEFINED LOOP PARAMETERS
maxloop = 200; E0 = 1; Emin = 1e-9; nu = 0.3;
Macro.length = Macro_struct(1); Macro.width = Macro_struct(2);
Micro.length = Micro_struct(1); Micro.width = Micro_struct(2);
Macro.nelx   = Macro_struct(3); Macro.nely  = Macro_struct(4);
Micro.nelx   = Micro_struct(3); Micro.nely  = Micro_struct(4);
Macro.Vol    = Macro_struct(5); Micro.Vol   = Micro_struct(5);
Macro.Elex = Macro.length/Macro.nelx; Macro.Eley = Macro.width/Macro.nely;
Macro.nele = Macro.nelx*Macro.nely;   Micro.nele = Micro.nelx*Micro.nely;
Macro.ndof = 2*(Macro.nelx+1)*(Macro.nely+1);
% PREPARE FINITE ELEMENT ANALYSIS
[load_x, load_y] = meshgrid(Macro.nelx, Macro.nely/2);
loadnid  = load_x*(Macro.nely+1)+(Macro.nely+1-load_y);
F = sparse(2*loadnid(:), 1, -1, 2*(Macro.nelx+1)*(Macro.nely+1),1);
U = zeros(Macro.ndof,1);
[fixed_x, fixed_y] = meshgrid(0, 0:Macro.nely);
fixednid  = fixed_x*(Macro.nely+1)+(Macro.nely+1-fixed_y);
fixeddofs = [2*fixednid(:); 2*fixednid(:)-1];
freedofs  = setdiff(1:Macro.ndof,fixeddofs);
nodenrs = reshape(1:(Macro.nely+1)*(Macro.nelx+1),1+Macro.nely,1+Macro.nelx);
edofVec = reshape(2*nodenrs(1:end-1,1:end-1)+1,Macro.nele,1);
edofMat = repmat(edofVec,1,8)+repmat([0 1 2*Macro.nely+[2 3 0 1] -2 -1],Macro.nele,1);
iK = reshape(kron(edofMat,ones(8,1))',64*Macro.nele,1);
jK = reshape(kron(edofMat,ones(1,8))',64*Macro.nele,1);
% PREPARE FILTER
[Macro.H,Macro.Hs] = filtering2d(Macro.nelx, Macro.nely, Macro.nele, rmin);
[Micro.H,Micro.Hs] = filtering2d(Micro.nelx, Micro.nely, Micro.nele, rmin);
% INITIALIZE ITERATION
Macro.x = repmat(Macro.Vol,Macro.nely,Macro.nelx);
Micro.x = ones(Micro.nely,Micro.nelx);
for i = 1:Micro.nelx
    for j = 1:Micro.nely
        if sqrt((i-Micro.nelx/2-0.5)^2+(j-Micro.nely/2-0.5)^2) < min(Micro.nelx,Micro.nely)/3
            Micro.x(j,i) = 0;
        end
    end
end
beta = 1;
Macro.xTilde = Macro.x; Micro.xTilde = Micro.x;
Macro.xPhys = 1-exp(-beta*Macro.xTilde)+Macro.xTilde*exp(-beta);
Micro.xPhys = 1-exp(-beta*Micro.xTilde)+Micro.xTilde*exp(-beta);
loopbeta = 0; loop = 0; Macro.change = 1; Micro.change = 1;
while loop < maxloop || Macro.change > 0.01 || Micro.change > 0.01
    loop = loop+1; loopbeta = loopbeta+1;
    % FE-ANALYSIS AT TWO SCALES
    [DH, dDH] = EBHM2D(Micro.xPhys, Micro.length, Micro.width, E0, Emin, nu, penal);
    Ke = elementMatVec2D(Macro.Elex/2, Macro.Eley/2, DH);
    sK = reshape(Ke(:)*(Emin+Macro.xPhys(:)'.^penal*(1-Emin)),64*Macro.nele,1);
    K = sparse(iK,jK,sK); K = (K+K')/2;
    U(freedofs,:) = K(freedofs,freedofs)\F(freedofs,:);
    % OBJECTIVE FUNCTION AND SENSITIVITY ANALYSIS
    ce = reshape(sum((U(edofMat)*Ke).*U(edofMat),2),Macro.nely,Macro.nelx);
    c = sum(sum((Emin+Macro.xPhys.^penal*(1-Emin)).*ce));
    Macro.dc = -penal*(1-Emin)*Macro.xPhys.^(penal-1).*ce;
    Macro.dv = ones(Macro.nely, Macro.nelx);
    Micro.dc = zeros(Micro.nely, Micro.nelx);
    for i = 1:Micro.nele
        dDHe = [dDH{1,1}(i) dDH{1,2}(i) dDH{1,3}(i);
                dDH{2,1}(i) dDH{2,2}(i) dDH{2,3}(i);
                dDH{3,1}(i) dDH{3,2}(i) dDH{3,3}(i)];
        [dKE] = elementMatVec2D(Macro.Elex, Macro.Eley, dDHe);
        dce = reshape(sum((U(edofMat)*dKE).*U(edofMat),2),Macro.nely,Macro.nelx);
        Micro.dc(i) = -sum(sum((Emin+Macro.xPhys.^penal*(1-Emin)).*dce));
    end
    Micro.dv = ones(Micro.nely, Micro.nelx);
    % FILTERING AND MODIFICATION OF SENSITIVITIES
    Macro.dx = beta*exp(-beta*Macro.xTilde)+exp(-beta); Micro.dx = beta*exp(-beta*Micro.xTilde)+exp(-beta);
    Macro.dc(:) = Macro.H*(Macro.dc(:).*Macro.dx(:)./Macro.Hs); Macro.dv(:) = Macro.H*(Macro.dv(:).*Macro.dx(:)./Macro.Hs);
    Micro.dc(:) = Micro.H*(Micro.dc(:).*Micro.dx(:)./Micro.Hs); Micro.dv(:) = Micro.H*(Micro.dv(:).*Micro.dx(:)./Micro.Hs);
    % OPTIMALITY CRITERIA UPDATE MACRO AND MICRO ELELMENT DENSITIES
    [Macro.x, Macro.xPhys, Macro.change] = OC(Macro.x, Macro.dc, Macro.dv, Macro.H, Macro.Hs, Macro.Vol, Macro.nele, 0.2, beta);
    [Micro.x, Micro.xPhys, Micro.change] = OC(Micro.x, Micro.dc, Micro.dv, Micro.H, Micro.Hs, Micro.Vol, Micro.nele, 0.2, beta);
    Macro.xPhys = reshape(Macro.xPhys, Macro.nely, Macro.nelx); Micro.xPhys = reshape(Micro.xPhys, Micro.nely, Micro.nelx);
    % PRINT RESULTS
    fprintf(' It.:%5i Obj.:%11.4f Macro_Vol.:%7.3f Micro_Vol.:%7.3f Macro_ch.:%7.3f Micro_ch.:%7.3f\n',...
        loop,c,mean(Macro.xPhys(:)),mean(Micro.xPhys(:)), Macro.change, Micro.change);
    figure(1);colormap(gray); imagesc(1-Macro.xPhys); caxis([0 1]); axis equal; axis off; drawnow;
    figure(2);colormap(gray); imagesc(1-Micro.xPhys); caxis([0 1]); axis equal; axis off; drawnow;
    %% UPDATE HEAVISIDE REGULARIZATION PARAMETER
    if beta < 512 && (loopbeta >= 50 || Macro.change <= 0.01 || Micro.change <= 0.01)
        beta = 2*beta; loopbeta = 0; Macro.change = 1; Micro.change = 1;
        fprintf('Parameter beta increased to %g.\n',beta);
    end
end
end