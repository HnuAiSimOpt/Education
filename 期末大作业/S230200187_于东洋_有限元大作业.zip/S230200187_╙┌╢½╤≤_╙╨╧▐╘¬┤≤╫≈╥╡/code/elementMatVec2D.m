function Ke = elementMatVec2D(a, b, DH)
GaussNodes = [-1/sqrt(3); 1/sqrt(3)]; GaussWeigh = [1 1];
L = [1 0 0 0; 0 0 0 1; 0 1 1 0];
Ke = zeros(8,8);
for i = 1:2
    for j = 1:2
        GN_x = GaussNodes(i); GN_y = GaussNodes(j);
        dN_x = 1/4*[-(1-GN_x)  (1-GN_x) (1+GN_x) -(1+GN_x)];
        dN_y = 1/4*[-(1-GN_y) -(1+GN_y) (1+GN_y)  (1-GN_y)];
        J = [dN_x; dN_y]*[ -a  a  a  -a;  -b  -b  b  b]';
        G = [inv(J) zeros(size(J)); zeros(size(J)) inv(J)];
        dN(1,1:2:8) = dN_x; dN(2,1:2:8) = dN_y;
        dN(3,2:2:8) = dN_x; dN(4,2:2:8) = dN_y;
        Be = L*G*dN;
        Ke = Ke + GaussWeigh(i)*GaussWeigh(j)*det(J)*Be'*DH*Be;
    end
end
end