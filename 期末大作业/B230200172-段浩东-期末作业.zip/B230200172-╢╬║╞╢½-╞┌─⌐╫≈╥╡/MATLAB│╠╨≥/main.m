%定义材料属性
E=210000000;
NU=0.3;
h=0.025;
%计算单元刚度矩阵
k1=BilinearQuadElementStiffness(E,NU,h,0,0,0.25,0,0.25,0.25,0,0.25,1);
k2=BilinearQuadElementStiffness(E,NU,h,0.25,0,0.5,0,0.5,0.25,0.25,0.25,1);
k3=BilinearQuadElementStiffness(E,NU,h,0,0.25,0.25,0.25,0.25,0.5,0,0.5,1);
%计算系统刚度矩阵
K=zeros(16,16);
K=BilinearQuadAssemble(K,k1,1,2,5,4);
K=BilinearQuadAssemble(K,k2,2,3,6,5);
K=BilinearQuadAssemble(K,k3,4,5,8,7);
%设置边界条件
U1x=0;U1y=0;U4x=0;U4y=0;U7x=0;U7y=0;
F2x=0;F2y=0;F3x=0;F3y=0;F6x=0;F6y=0;F8x=0;F8y=0;
F5x=0;F5y=-12.5;
%解方程
k=[K(3:6,3:6),K(3:6,9:12),K(3:6,15:16); K(9:12,3:6),K(9:12,9:12),K(9:12,15:16);  K(15:16,3:6),K(15:16,9:12),K(15:16,15:16)];
f=[0;0;0;0;0;-12.5;0;0;0;0];
%节点位移
u=k\f;              %\用于高斯消去法
%6、后处理
%求节点1、4、7支反力
U=[0;0;u(1:4);0;0;u(5:8);0;0;u(9:10)];
F=K*U;
%计算每一个单元的应力
u1=[U(1);U(2);U(3);U(4);U(9);U(10);U(7);U(8)];
u2=[U(3);U(4);U(5);U(6);U(11);U(12);U(9);U(10)];
u3=[U(7);U(8);U(9);U(10);U(15);U(16);U(13);U(14)];
sigma1=BilinearQuadElementStresses(E,NU,0,0,0.25,0,0.25,0.25,0,0.25,1,u1);
sigma2=BilinearQuadElementStresses(E,NU,0.25,0,0.5,0,0.5,0.25,0.25,0.25,1,u2);
sigma3=BilinearQuadElementStresses(E,NU,0,0.25,0.25,0.25,0.25,0.5,0,0.5,1,u3);
%计算每一个单元主应力
s1=BilinearQuadElementPStresses(sigma1);
s2=BilinearQuadElementPStresses(sigma2);
s3=BilinearQuadElementPStresses(sigma3);

