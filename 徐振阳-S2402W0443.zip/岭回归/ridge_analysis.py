
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge, RidgeCV
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import os

# 1) 生成模拟数据（包含多重共线性）
np.random.seed(42)
n_samples = 320
n_features = 12

Z = np.random.randn(n_samples, 3)
X = np.zeros((n_samples, n_features))

X[:, 0] = 0.8*Z[:, 0] + 0.2*np.random.randn(n_samples)
X[:, 1] = 0.75*Z[:, 0] + 0.25*np.random.randn(n_samples)
X[:, 2] = 0.85*Z[:, 0] + 0.15*np.random.randn(n_samples)

X[:, 3] = 0.9*Z[:, 1] + 0.1*np.random.randn(n_samples)
X[:, 4] = 0.88*Z[:, 1] + 0.12*np.random.randn(n_samples)

X[:, 5] = 0.92*Z[:, 2] + 0.08*np.random.randn(n_samples)
X[:, 6] = 0.86*Z[:, 2] + 0.14*np.random.randn(n_samples)

X[:, 7]  = 0.5*Z[:, 0] + 0.5*Z[:, 1] + 0.2*np.random.randn(n_samples)
X[:, 8]  = 0.5*Z[:, 1] + 0.5*Z[:, 2] + 0.2*np.random.randn(n_samples)
X[:, 9]  = 0.5*Z[:, 0] + 0.5*Z[:, 2] + 0.2*np.random.randn(n_samples)
X[:, 10] = 0.33*Z[:, 0] + 0.33*Z[:, 1] + 0.33*Z[:, 2] + 0.2*np.random.randn(n_samples)
X[:, 11] = np.random.randn(n_samples)

beta_true = np.array([3.0, 2.5, 0.0,
                      2.0, 0.0,
                      1.5, 0.0,
                      1.0, 0.7, 0.0,
                      0.5, 0.0])

noise = 0.8*np.random.randn(n_samples)
y = X @ beta_true + noise

feature_names = [f"X{i+1}" for i in range(n_features)]
df = pd.DataFrame(X, columns=feature_names)
df["y"] = y

os.makedirs("output", exist_ok=True)
df.to_csv("output/ridge_dataset.csv", index=False)

# 2) 训练测试划分与标准化
X_train, X_test, y_train, y_test = train_test_split(df[feature_names].values, df["y"].values,
                                                    test_size=0.25, random_state=17)
scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s  = scaler.transform(X_test)

# 3) 岭回归 + 交叉验证
alphas = np.logspace(-3, 3, 60)
cv = KFold(n_splits=5, shuffle=True, random_state=17)
ridge_cv = RidgeCV(alphas=alphas, cv=cv, scoring="neg_mean_squared_error")
ridge_cv.fit(X_train_s, y_train)
best_alpha = ridge_cv.alpha_

ridge = Ridge(alpha=best_alpha)
ridge.fit(X_train_s, y_train)

# 4) 评估
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

y_train_pred = ridge.predict(X_train_s)
y_test_pred  = ridge.predict(X_test_s)

metrics = pd.DataFrame({
    "split": ["train", "test"],
    "R2": [r2_score(y_train, y_train_pred), r2_score(y_test, y_test_pred)],
    "MAE": [mean_absolute_error(y_train, y_train_pred), mean_absolute_error(y_test, y_test_pred)],
    "RMSE": [rmse(y_train, y_train_pred), rmse(y_test, y_test_pred)],
})
metrics.to_csv("output/ridge_metrics.csv", index=False)

# 5) 可视化
coef_list = []
for a in alphas:
    r = Ridge(alpha=a)
    r.fit(X_train_s, y_train)
    coef_list.append(r.coef_)
coef_mat = np.array(coef_list)

plt.figure()
for j in range(n_features):
    plt.plot(np.log10(alphas), coef_mat[:, j], label=feature_names[j])
plt.axvline(np.log10(best_alpha), color="r", linestyle="--")
plt.xlabel("log10(alpha)")
plt.ylabel("Coefficient")
plt.title("Ridge 系数路径")
plt.savefig("output/ridge_coef_path.png", dpi=160)
plt.close()

plt.figure()
plt.scatter(y_test, y_test_pred)
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], color="r")
plt.xlabel("实际值")
plt.ylabel("预测值")
plt.title("预测值 vs 实际值")
plt.savefig("output/ridge_pred_vs_actual.png", dpi=160)
plt.close()

resid_test = y_test - y_test_pred
plt.figure()
plt.scatter(y_test_pred, resid_test)
plt.axhline(0, color="r", linestyle="--")
plt.xlabel("拟合值")
plt.ylabel("残差")
plt.title("残差 vs 拟合值")
plt.savefig("output/ridge_residuals.png", dpi=160)
plt.close()

# 6) 保存系数
coef_df = pd.DataFrame({
    "feature": feature_names,
    "coef_standardized": ridge.coef_
}).sort_values(by="coef_standardized", key=abs, ascending=False)
coef_df.to_csv("output/ridge_final_coefficients.csv", index=False)

print("分析完成，结果保存在 output 文件夹。")
