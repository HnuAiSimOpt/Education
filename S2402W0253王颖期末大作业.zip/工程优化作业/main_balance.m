clc; clear; close all;

%% 参数设置
params.m0 = 10;       % g, 被平衡对象的偏心质量
params.r0 = 0.05;     % m, 偏心距
params.phi0 = 270;    % deg, 初始相位

params.mA = 20;       % g, A盘偏心质量
params.rA = 0.05;     % m, 偏心距
params.phiA = 40;     % deg, 初始相位

params.mB = 20;       % g, B盘偏心质量
params.rB = 0.05;     % m, 偏心距
params.phiB = 140;    % deg, 初始相位

params.max_iter = 60;   % 最大迭代次数
params.tol = 1e-3;      % 收敛阈值
params.step = pi/12;    % 初始转动步长

%% 调用仿真函数
[result, history] = async_balance(params);

%% ================= 绘制结果 ==================
figure;
plot(1:result.iterations, history.unbalance, '-o','LineWidth',1.5);
xlabel('步数'); ylabel('不平衡量 |M_t|');
title('基于贪心算法的异步动平衡过程');
grid on;

figure;
plot(1:result.iterations, history.phiA, '-s','LineWidth',1.5); hold on;
plot(1:result.iterations, history.phiB, '-d','LineWidth',1.5);
xlabel('步数'); ylabel('相位 (deg)');
title('平衡盘 A 和 B 相位变化');
legend('A盘相位','B盘相位'); grid on;

figure;
plot(real(history.Mt), imag(history.Mt), '-o','LineWidth',1.5);
xlabel('Re(M_t)'); ylabel('Im(M_t)');
title('不平衡向量轨迹（复平面）');
axis equal; grid on;

figure;
plot(1:result.iterations, history.step, '-x','LineWidth',1.5);
xlabel('步数'); ylabel('步长 (rad)');
title('步长变化过程');
grid on;
