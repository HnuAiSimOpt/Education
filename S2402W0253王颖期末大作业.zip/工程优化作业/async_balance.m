function [result, history] = async_balance(params)
    % 初始化
    phiA = deg2rad(params.phiA);
    phiB = deg2rad(params.phiB);
    step = params.step;
    count = 0;

    % 初始不平衡
    M0 = params.m0 * params.r0 * exp(1j*deg2rad(params.phi0));
    MA = params.mA * params.rA * exp(1j*phiA);
    MB = params.mB * params.rB * exp(1j*phiB);
    Mt = M0 + MA + MB;

    % 历史数据
    history.unbalance = abs(Mt);
    history.phiA = rad2deg(phiA);
    history.phiB = rad2deg(phiB);
    history.step = step;
    history.Mt = Mt;

    % 异步迭代
    for k = 1:params.max_iter
        if mod(k,2) == 1
            % 奇数步：调整 A盘
            trialA = phiA + step;
            MA_trial = params.mA * params.rA * exp(1j*trialA);
            Mt_trial = M0 + MA_trial + MB;

            if abs(Mt_trial) < abs(Mt)
                phiA = trialA; MA = MA_trial; Mt = Mt_trial;
                count = 0;
            else
                count = count + 1;
                if count == 1
                    step = step/2; % 超调
                elseif count == 2
                    step = -step; count = 0; % 换方向
                end
            end
        else
            % 偶数步：调整 B盘
            trialB = phiB + step;
            MB_trial = params.mB * params.rB * exp(1j*trialB);
            Mt_trial = M0 + MA + MB_trial;

            if abs(Mt_trial) < abs(Mt)
                phiB = trialB; MB = MB_trial; Mt = Mt_trial;
                count = 0;
            else
                count = count + 1;
                if count == 1
                    step = step/2;
                elseif count == 2
                    step = -step; count = 0;
                end
            end
        end

        % 保存历史
        history.unbalance(end+1) = abs(Mt);
        history.phiA(end+1) = rad2deg(phiA);
        history.phiB(end+1) = rad2deg(phiB);
        history.step(end+1) = step;
        history.Mt(end+1) = Mt;

        % 判断收敛
        if abs(Mt) < params.tol
            break;
        end
    end

    % 输出结果
    result.final_unbalance = abs(Mt);
    result.iterations = length(history.unbalance);
    result.phiA = rad2deg(phiA);
    result.phiB = rad2deg(phiB);
end
