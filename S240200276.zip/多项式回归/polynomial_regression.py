# polynomial_regression.py
# Reproducible script to generate dataset and fit polynomial regression (degrees 1..6)
import numpy as np
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import matplotlib.pyplot as plt

np.random.seed(42)
n_samples = 300
x = np.linspace(-3, 3, n_samples)
y_true = 1.5 * x**3 - 2.0 * x**2 + 0.5 * x + 3.0 + 4.0 * np.sin(1.5 * x)
noise = np.random.normal(0, 8.0, size=n_samples)
y = y_true + noise

df = pd.DataFrame({'x': x, 'y': y, 'y_true': y_true})
df.to_csv('polynomial_dataset.csv', index=False)

results = []
models = {}
for degree in range(1,7):
    poly = PolynomialFeatures(degree=degree, include_bias=False)
    X_poly = poly.fit_transform(x.reshape(-1,1))
    X_train, X_test, y_train, y_test = train_test_split(X_poly, y, test_size=0.2, random_state=42)
    lr = LinearRegression()
    lr.fit(X_train, y_train)
    y_pred = lr.predict(X_test)
    r2 = r2_score(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = mean_squared_error(y_test, y_pred, squared=False)
    cv = KFold(n_splits=5, shuffle=True, random_state=42)
    cv_scores = cross_val_score(lr, X_poly, y, scoring='r2', cv=cv)
    results.append({'degree': degree, 'r2_test': r2, 'mae_test': mae, 'rmse_test': rmse,
                    'cv_r2_mean': cv_scores.mean(), 'cv_r2_std': cv_scores.std()})
    models[degree] = (poly, lr)

results_df = pd.DataFrame(results)
print(results_df)
best_row = results_df.loc[results_df['cv_r2_mean'].idxmax()]
best_degree = int(best_row['degree'])
print('Best degree by CV R2 mean:', best_degree)
