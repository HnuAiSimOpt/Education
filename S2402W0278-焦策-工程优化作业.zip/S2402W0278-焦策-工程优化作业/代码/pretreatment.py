import cv2
import numpy as np

def image_preprocessing():
    # 读取图片
    img = cv2.imread("4.jpg")
    if img is None:
        print("Error: 无法读取图片，请检查路径是否正确！")
        return None

    # =====================图像处理======================== #
    # 转换成灰度图像
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # 进行高斯滤波（去噪）
    gauss_img = cv2.GaussianBlur(gray_img, (5, 5), 0, borderType=cv2.BORDER_DEFAULT)

    # 边缘检测（Canny参数可根据图片调整）
    img_edge1 = cv2.Canny(gauss_img, 50, 150)  # 降低阈值，更容易检测弱边缘
    # ==================================================== #


    # =====================图像分割（提取数字区域）======================== #
    # 获取原始图像的宽和高
    high, width = img_edge1.shape[:2]  # 优化：直接解构赋值

    # 计算每一行的像素和（用于定位上下边界）
    add_width = np.sum(img_edge1, axis=1)  # 优化：用numpy代替双重循环，效率提升100x+
    # 计算每一列的像素和（用于定位左右边界）
    add_high = np.sum(img_edge1, axis=0)

    # 定位有效区域（排除全黑的行/列）
    # 上边界：从顶部向下找第一个非零行
    acount_high_up = 0
    while acount_high_up < high and add_width[acount_high_up] == 0:
        acount_high_up += 1
    # 下边界：从底部向上找第一个非零行
    acount_high_down = high - 1
    while acount_high_down >= 0 and add_width[acount_high_down] == 0:
        acount_high_down -= 1

    # 左边界：从左向右找第一个非零列
    acount_width_left = 0
    while acount_width_left < width and add_high[acount_width_left] == 0:
        acount_width_left += 1
    # 右边界：从右向左找第一个非零列
    acount_width_right = width - 1
    while acount_width_right >= 0 and add_high[acount_width_right] == 0:
        acount_width_right -= 1

    # 防止边界定位失败（全黑图像）
    if (acount_high_up >= acount_high_down) or (acount_width_left >= acount_width_right):
        print("Error: 未检测到有效数字区域！")
        return None

    # 计算宽高间距，并添加适当的边距（避免裁剪到数字边缘）
    width_spacing = acount_width_right - acount_width_left
    high_spacing = acount_high_down - acount_high_up  # 修复：原逻辑上下边界顺序反了
    margin = 5  # 边距大小

    # 正方形裁剪：确保裁剪区域为正方形，方便后续缩放为28x28
    center_x = (acount_width_left + acount_width_right) // 2
    center_y = (acount_high_up + acount_high_down) // 2
    max_size = max(width_spacing, high_spacing) // 2 + margin  # 正方形边长的一半

    # 计算裁剪边界（避免超出原图范围）
    x1 = max(0, center_x - max_size)
    x2 = min(width, center_x + max_size)
    y1 = max(0, center_y - max_size)
    y2 = min(high, center_y + max_size)

    # 裁剪数字区域
    tailor_image = img[y1:y2, x1:x2]
    # ==================================================== #


    # ======================小图处理（适配MNIST格式）======================= #
    # 灰度化
    gray_tailor = cv2.cvtColor(tailor_image, cv2.COLOR_BGR2GRAY)

    # 高斯去噪
    gauss_tailor = cv2.GaussianBlur(gray_tailor, (5, 5), 0)

    # 二值化（固定阈值，将数字变为白色，背景变为黑色）
    _, binary_img = cv2.threshold(gauss_tailor, 127, 255, cv2.THRESH_BINARY_INV)  # 反阈值：黑底白字

    # 缩放为28x28（MNIST输入尺寸）
    zoom_image = cv2.resize(binary_img, (28, 28), interpolation=cv2.INTER_AREA)

    # 归一化（MNIST数据范围是0-1，且为float32类型）
    zoom_image = zoom_image.astype(np.float32) / 255.0
    # ==================================================== #

    return zoom_image


# 测试函数
if __name__ == "__main__":
    processed_img = image_preprocessing()
    if processed_img is not None:
        # 显示处理后的图像（需要转换回uint8才能显示）
        cv2.imshow("Processed Image", (processed_img * 255).astype(np.uint8))
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        # 保存处理后的图像
        cv2.imwrite("processed.jpg", (processed_img * 255).astype(np.uint8))