import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import os

# 下载训练集
train_dataset = datasets.MNIST(
    root='./data/',
    train=True,
    transform=transforms.ToTensor(),
    download=True
)
# 下载测试集
test_dataset = datasets.MNIST(
    root='./data/',
    train=False,
    transform=transforms.ToTensor(),
    download=True
)

# 设置批次数
batch_size = 100

# 训练集
train_loader = DataLoader(
    dataset=train_dataset,
    batch_size=batch_size,
    shuffle=True
)
# 测试集
test_loader = DataLoader(
    dataset=test_dataset,
    batch_size=batch_size,
    shuffle=True
)


# 定义CNN模型
class CNN(nn.Module):
    def __init__(self):
        super(CNN, self).__init__()

        self.Conn_layers = nn.Sequential(
            nn.Linear(784, 100),
            nn.Sigmoid(),
            nn.Linear(100, 10),
            nn.Sigmoid()
        )

    def forward(self, input):
        output = self.Conn_layers(input)
        return output


# 定义学习率
LR = 0.1

# 定义网络对象
model = CNN()

# 损失函数使用交叉熵
loss_function = nn.CrossEntropyLoss()

# 优化函数使用 SGD
optimizer = optim.SGD(
    model.parameters(),
    lr=LR,
    momentum=0.9,
    weight_decay=0.0005
)

# 定义迭代次数
epochs = 50  # 变量名修改为epochs避免与循环变量冲突

# 进行迭代训练
for epoch in range(epochs):
    # 训练模式
    model.train()
    for i, data in enumerate(train_loader):
        inputs, labels = data
        # 转换输入形状，使用inputs.size(0)获取实际批次大小
        inputs = inputs.reshape(inputs.size(0), 784)

        outputs = model(inputs)
        loss = loss_function(outputs, labels)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    # 测试模式
    model.eval()
    test_result = 0

    # 关闭梯度计算，提高测试速度
    with torch.no_grad():
        for data_test in test_loader:
            images, labels = data_test
            # 转换输入形状
            images = images.reshape(images.size(0), 784)

            output_test = model(images)
            # 使用更高效的方式计算准确率
            predicted = torch.argmax(output_test, dim=1)
            test_result += (predicted == labels).sum().item()

    # 打印每次迭代后的准确率
    accuracy = test_result / len(test_dataset)
    print(f"Epoch {epoch + 1}/{epochs}: {test_result}/{len(test_dataset)} ({accuracy:.4f})")

# 确保保存目录存在
if not os.path.exists('weight'):
    os.makedirs('weight')


# 保存整个模型
torch.save(model, 'weight/test.pkl')
