import torch
import torch.nn as nn
import numpy as np
import pretreatment as PRE

# 1. 定义模型
class CNN(nn.Module):
    def __init__(self):
        super(CNN, self).__init__()
        self.Conn_layers = nn.Sequential(
            nn.Linear(784, 100),
            nn.Sigmoid(),
            nn.Linear(100, 10),
            nn.Sigmoid()
        )
    def forward(self, input):
        return self.Conn_layers(input)

# 2. 加载已有的 .pkl 完整模型（添加 weights_only=False 适配 PyTorch 2.6+）
model = torch.load('weight/test.pkl', weights_only=False)
model.eval()  # 切换到评估模式

# 图像处理及打印预测结果
img = PRE.image_preprocessing()
if img is None:
    print("图片预处理失败")
    exit()
inputs = torch.from_numpy(img).reshape(-1, 784).float()
with torch.no_grad():
    predict = model(inputs)
print(f"The number in this picture is {torch.argmax(predict).item()}")