%%%%%%%%%%%  ����λ�Ƴ���  %%%%%%%%%%%
function [U]=StaticsSolver(E,u,Forces,Constraints,Nodes,Elements)
Dof=3;
NodeCount = size(Nodes,1);  
ElementCount= size(Elements,1);  
Dofs = Dof*NodeCount; 
U=sparse(Dofs,1);	
K = sparse(Dofs,Dofs);  
Force = sparse(Dofs,1);  
D=LinearIsotropicD(E,u);
for I=1:ElementCount
    ElementNodeCoordinate=Nodes(Elements(I,:),:);
    ElementStiffnessMatrix=Ke(D,ElementNodeCoordinate);
    ElementNodeDOF=zeros(1,24);
    for J=1:8
        II=(J-1)*Dof+1;
        ElementNodeDOF(II:II+2)=(Elements(I,J)-1)*Dof+1:(Elements(I,J)-1)*Dof+3;
    end
    K(ElementNodeDOF,ElementNodeDOF)=K(ElementNodeDOF,ElementNodeDOF)+ElementStiffnessMatrix;
end
if size(Forces,1)>0
    ForceDOF = Dof*(Forces(:,1)-1)+Forces(:,2); 
    Force(ForceDOF) = Force(ForceDOF) + Forces(:,3);
end
BigNumber=1e8;
ConstraintsNumber=size(Constraints,1);
if ConstraintsNumber~=0
    FixedDof=Dof*(Constraints(:,1)-1)+Constraints(:,2); 
    for i=1:ConstraintsNumber
        K(FixedDof(i),FixedDof(i))=K(FixedDof(i),FixedDof(i))*BigNumber;
        Force(FixedDof(i))=Constraints(i,3)*K(FixedDof(i),FixedDof(i));
    end
end
U = K\Force;
end