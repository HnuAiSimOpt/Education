function [Nodes, Elements] = Readmesh( fname )
fid = fopen(fname,'rt'); 
S = textscan(fid,'%s','Delimiter','\n'); 
S = S{1};
idxS = strfind(S, 'Node');  
idx1 = find(not(cellfun(@isempty, idxS))); 
idxS = strfind(S, 'Element');
idx2 = find(not(cellfun(@isempty, idxS)));
idxS = strfind(S, 'Nset');
idx3 = find(not(cellfun(@isempty, idxS)));
Nodes = S(idx1(1)+1:idx2(1)-1);
Nodes = cell2mat(cellfun(@str2num,Nodes,'UniformOutput',false)); 
elements = S(idx2+1:idx3(1)-1) ;
Elements = cell2mat(cellfun(@str2num,elements,'UniformOutput',false));
Nodes=Nodes(:,2:end);
Elements=Elements(:,2:end);
end