clc;clear;
syms A1 A2 A3 B1 B2 B3 x y u E h b
u=0.3;
E=2*10^11;
h=2;
ex=A1+A2*(2*x-h)+A3*y;    %x����Ӧ��
ey=B3*(x-h);              %y����Ӧ��
yxy=B1+B2*(2*x-h)+B3*y+A3*(x-h); %xy������Ӧ��
ox=(E/(1-u*u))*(ex+u*ey); %x����Ӧ��
oy=(E/(1-u*u))*(ey+u*ex);  %y����Ӧ��
txy=(E/(2*(1+u)))*yxy ;      %xy������Ӧ��
W=ox*ex+oy*ey+yxy*txy;
W=int(W,'y',-b/2,b/2);
U=(1/2)*int(W,'x',0,h);  %Ӧ����
%%
UA1=diff(U,A1);
UA1=collect(UA1);
UA2=diff(U,A2);
UA2=collect(UA2);
UA3=diff(U,A3);
UA3=collect(UA3);
UB1=diff(U,B1);
UB1=collect(UB1);
UB2=diff(U,B2);
UB2=collect(UB2);
UB3=diff(U,B3);
UB3=collect(UB3);
%%
q1=200;q2=100;
u1=-q2*(x-h);
u2=-q2*x*(x-h);
u3=-q2*y*(x-h);
pxu1=int(u1,'x',0,h);
pxu2=int(u2,'x',0,h);
pxu3=int(u3,'x',0,h);
v1=q1*(x-h);
v2=q1*x*(x-h);
v3=q1*y*(x-h);
pxv1=int(v1,'x',0,h);
pxv2=int(v2,'x',0,h);
pxv3=int(v3,'x',0,h);
%%
[A1 A2 A3 B1 B2 B3] = solve('((2*B3*2*10^11)*0.3 - 2*A1*2*10^11)/(0.3^2 - 1)==200', '((-4*B3*2*10^11)*0.3 - 8*A2*2*10^11)/(3*0.3^2 - 3)==400/3', '((8*A3*2*10^11 - 6*B1*2*10^11 + 4*B2*2*10^11)*0.3 + 6*B1*2*10^11 - 9*A3*2*10^11 - 4*B2*2*10^11)/(6*0.3^2 - 6)==100','(B1*2*10^11 - A3*2*10^11)/(0.3 + 1)==-400','(2*A3*2*10^11 + 4*B2*2*10^11)/(3*0.3 + 3)==-800/3','((24*A1*2*10^11 - 16*A2*2*10^11 + B3*2*10^11)*0.3 - 33*B3*2*10^11)/(12*0.3^2 - 12)==200',A1,A2,A3,B1,B2,B3)
u=0.3;E=2*10^11;h=2;
uu=(x-2)*(A1+A2*x+A3*y);uu=collect(uu);
vv=(x-2)*(B1+B2*x+B3*y);vv=collect(vv);
fu=inline(uu);
fv=inline(vv);
x1=[0,0.5,1,1.5,2];y1=[-0.5,0,0.5];S=zeros(2,5);
for i=1:5
    S(1,i)=fu(x1(i),0);
    S(2,i)=fv(x1(i),0);
end
ex=A1+A2*(2*x-h)+A3*y;    %x����Ӧ��
ey=B3*(x-h);              %y����Ӧ��
yxy=B1+B2*(2*x-h)+B3*y+A3*(x-h); %xy������Ӧ��
ox=(E/(1-u*u))*(ex+u*ey); %x����Ӧ��
fox=inline(ox);
oy=(E/(1-u*u))*(ey+u*ex);  %y����Ӧ��
foy=inline(oy);
txy=(E/(2*(1+u)))*yxy ;      %xy������Ӧ��
ftxy=inline(txy);
P=zeros(3,5);
for j=1:5
    P(1,j)=fox(x1(j),-0.5);
    P(2,j)=foy(x1(j),-0.5);
    P(3,j)=ftxy(x1(j),-0.5);
end