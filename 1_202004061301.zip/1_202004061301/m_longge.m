%车辆2003班 许少辉 202004061301
%2023.03.20
%验证龙格现象

clc
clear%清除工作区存储
x=-5:0.01:5;%计算函数f(x)=1/(1+x2)，x∈[-5,5]的x、y初始值
y=1./(1+x.^2);
for i=1:10%循环，依次计算并画出拉格朗日插值从1到10的函数，这里可以修改插值的次数
xx=-5:10/i:5;%插值点的计算
y1=1./(1+xx.^2);
yy1=lagrange(xx,y1,x);%拉格朗日插值拟合
figure%绘图
grid on%打开网格
hold on
plot(x,yy1,'-r')%红色实线表示插值函数图
hold on
plot(x,y,'-b')%红色实线表示原始函数图
axis([-6 6 -1 2])%图示坐标值
hold on
legend( "插值函数","1/（1+x^2）函数图");%图例
title('拉格朗日插值','FontSize',15,'FontName','Microsft YaHei UI')%题目
end
function y=lagrange(xi, fi, x)%拉格朗日插值函数编写
n=length(xi)-1;%计算插值量
y=zeros(size(x));%创建全零数组以存储插值函数的y值
for k=0:n%该循环用于计算Ln(x)=∑y*l(xk)=y
   num=ones(size(x));
   den=1;
   for j=0:n%该循环用于计算ω(x)和ω`(x)
       if j==k%排除在循环过程中，出现同一插值的情况
           continue;
       else
      num=num.*(x-xi(j+1));%计算ω(x)
      den=den*(xi(k+1)-xi(j+1));%计算ω`(x)
       end
   end
   l=num/den;%计算l（xk）
   y=y+fi(k+1).*l;%计算插值函数   
end
end