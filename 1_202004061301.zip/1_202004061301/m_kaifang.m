x=[88.9 108.5 104.1 139.7 127 94 116.8 99.1];
y=[14.6 16.7 15.3 23.2 19.5 16.1 18.1 16.6];
figure
plot(x,y,'r.');%绘制数据点
grid on
xlabel('降水');
ylabel('流速');
theta1=0;   %一次项系数
theta0=0;   %常系数
v=0.00001; %设置步长
[row,col]=size(x);   %一次项系数和常系数初始化
theta1 = mean(y)/mean(x)
theta0 = y(1)-theta1*x(1)
while 1     %梯度下降，进行循环直到找到最优解退出循环
    temp1=0;%
    temp0=0;
    for i=1:col%对损失函数求导
        temp1 = temp1 - ((y(i) - (theta1*x(i) + theta0)) * x(i));
        temp0=temp0-((y(i)-(theta1*x(i)+theta0))*1);
        end
    old_theta1=theta1;%前一个常系数和一次项系数存储以后续比较
    old_theta0=theta0;
    theta1 = theta1- v*temp1%更新每个样本的常系数和一次项系数
    theta0 =theta0 - v*temp0
    temp1=0;
    temp0=0;
    e =((old_theta1-theta1)^2+(old_theta0-theta0)^2)%误差判别
    if e<0.000003
        f=theta1*x+theta0;%绘图
        hold on
        plot(x,y,'r+',x,f)
        legend( "数据点","拟合直线");%图例
        title('降水与流速拟合图','FontSize',15,'FontName','Microsft YaHei UI')%题目
        break;
     end
end
TSS=0%计算拟合度
RSS=0
    for j=1:length(x)
        TSS=TSS+(y(j)-mean(y))^2;
        RSS=RSS+(f(j)-y(j))^2;
    end
    R=1-RSS/TSS



