# jssp_bfgs.py
# -*- coding: utf-8 -*-
"""
基于 PyTorch 的作业车间调度（JSSP）可微优化 + 拟牛顿(BFGS) + 线搜索 + 可行化后处理 + Gantt 可视化
"""

from dataclasses import dataclass
from typing import List, Tuple, Dict, Any
import math
import torch
import matplotlib.pyplot as plt


# =========================
# 数据结构与工具
# =========================
@dataclass
class Operation:
    job: int
    op_idx: int
    machine: int
    duration: float


@dataclass
class JSSPInstance:
    instance_id: str
    num_jobs: int
    num_machines: int
    jobs: List[List[Dict[str, float]]]  # 每个作业是操作列表：{"machine": int, "duration": float}
    optimal_makespan: float = None

    @staticmethod
    def from_starjob_dict(data: Dict[str, Any]) -> "JSSPInstance":
        return JSSPInstance(
            instance_id=data.get("instance_id", "unknown"),
            num_jobs=data["num_jobs"],
            num_machines=data["num_machines"],
            jobs=data["jobs"],
            optimal_makespan=data.get("optimal_makespan", None),
        )

    def flatten_operations(self) -> List[Operation]:
        ops: List[Operation] = []
        for i in range(self.num_jobs):
            for j, op in enumerate(self.jobs[i]):
                ops.append(Operation(job=i, op_idx=j, machine=int(op["machine"]), duration=float(op["duration"])))
        return ops


# =========================
# 可微目标函数构建
# =========================
class DifferentiableJSSP:
    """
    将开始时间变量 S_ij 作为可微变量（通过 softplus(theta_ij) 保证非负），
    构造 makespan 的 LogSumExp 近似 + 顺序约束惩罚 + 机器容量惩罚 + L2 正则。
    """
    def __init__(self, ins: JSSPInstance, beta: float = 10.0, lam_l2: float = 1e-4,
                 w_seq: float = 10.0, w_cap: float = 10.0, device: str = "cpu"):
        self.ins = ins
        self.beta = beta          # LogSumExp 的平滑参数
        self.lam_l2 = lam_l2      # L2 正则权重
        self.w_seq = w_seq        # 顺序惩罚权重
        self.w_cap = w_cap        # 机器容量惩罚权重
        self.device = device

        # 建立操作索引映射：op_id <-> (job, op_idx)
        self.ops: List[Operation] = self.ins.flatten_operations()
        self.num_ops = len(self.ops)

        # 为每个操作建立索引，便于张量化
        self.op_index = {(op.job, op.op_idx): idx for idx, op in enumerate(self.ops)}

        # durations 和 machine ids 张量
        self.durations = torch.tensor([op.duration for op in self.ops], dtype=torch.float32, device=self.device)
        self.machines = torch.tensor([op.machine for op in self.ops], dtype=torch.long, device=self.device)

        # 每个作业最后一个操作的 op 索引（用于 makespan）
        self.last_op_index_per_job = torch.tensor(
            [self.op_index[(i, len(self.ins.jobs[i]) - 1)] for i in range(self.ins.num_jobs)],
            dtype=torch.long, device=self.device
        )

        # 初始化可学习参数：theta（未约束），通过 softplus(theta) -> S >= 0
        torch.manual_seed(0)
        self.theta = torch.randn(self.num_ops, dtype=torch.float32, device=self.device) * 0.1

    def soft_start_times(self, theta: torch.Tensor) -> torch.Tensor:
        # softplus 确保开始时间非负；加一个小常数提升数值稳定
        return torch.nn.functional.softplus(theta) + 1e-6

    def objective(self, theta: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        返回目标标量 J 以及分量字典（便于监控）：
        J = LSE_makespan + w_seq * P_seq + w_cap * P_cap + lam_l2 * ||theta||^2
        """
        S = self.soft_start_times(theta)              # (num_ops,)
        C = S + self.durations                        # 完成时间

        # --- 1) makespan 的 LogSumExp 近似 ---
        last_C = C[self.last_op_index_per_job]        # 各作业完成时间
        lse = torch.logsumexp(self.beta * last_C, dim=0) / self.beta

        # --- 2) 顺序惩罚：S_{i,j+1} >= C_{i,j} ---
        # 对每个作业 i，遍历 j -> j+1
        seq_penalty = S.new_zeros(())
        for i in range(self.ins.num_jobs):
            num_ops_i = len(self.ins.jobs[i])
            for j in range(num_ops_i - 1):
                a = self.op_index[(i, j)]
                b = self.op_index[(i, j + 1)]
                # 惩罚 ReLU(C_a - S_b)^2
                viol = torch.nn.functional.relu((C[a] - S[b]))
                seq_penalty = seq_penalty + viol * viol

        # --- 3) 机器容量惩罚：同机操作不重叠 ---
        # 对每台机器，拿到属于该机的操作集合，两两检测重叠
        cap_penalty = S.new_zeros(())
        for m in range(self.ins.num_machines):
            idx_m = (self.machines == m).nonzero(as_tuple=True)[0]
            # 两两组合
            for ii in range(len(idx_m)):
                for jj in range(ii + 1, len(idx_m)):
                    a = idx_m[ii]
                    b = idx_m[jj]
                    # overlap_len = min(Ca, Cb) - max(Sa, Sb)
                    minC = torch.minimum(C[a], C[b])
                    maxS = torch.maximum(S[a], S[b])
                    overlap = torch.nn.functional.relu(minC - maxS)
                    cap_penalty = cap_penalty + overlap * overlap

        # --- 4) L2 正则（在未约束空间 theta 上更稳）---
        l2 = torch.sum(self.theta * self.theta)

        J = lse + self.w_seq * seq_penalty + self.w_cap * cap_penalty + self.lam_l2 * l2
        parts = {
            "lse": lse.detach(),
            "seq_penalty": seq_penalty.detach(),
            "cap_penalty": cap_penalty.detach(),
            "l2": l2.detach()
        }
        return J, parts


# =========================
# 拟牛顿 BFGS + 回溯线搜索
# =========================
def bfgs_optimize(model: DifferentiableJSSP,
                  max_iters: int = 200,
                  tol: float = 1e-5,
                  ls_alpha0: float = 1.0,
                  ls_rho: float = 0.5,
                  ls_c: float = 1e-4,
                  verbose: bool = True) -> Tuple[torch.Tensor, List[Dict[str, float]]]:
    """
    简单的无约束拟牛顿 (BFGS) 优化器（在 theta 空间），带 Armijo 回溯线搜索。
    返回：最优 theta、日志列表。
    """
    theta = model.theta.clone().detach().requires_grad_(True)
    n = theta.numel()
    # 逆 Hessian 的初始近似
    invH = torch.eye(n, dtype=torch.float32, device=theta.device)

    logs: List[Dict[str, float]] = []
    prev_obj = None

    for it in range(1, max_iters + 1):
        # 前向与梯度
        obj, parts = model.objective(theta)
        if theta.grad is not None:
            theta.grad.zero_()
        obj.backward()
        g = theta.grad.detach().clone()  # 当前梯度

        # 收敛检查（目标相对变化）
        obj_val = float(obj.detach().cpu().item())
        if prev_obj is not None:
            rel_change = abs(obj_val - prev_obj) / max(1.0, abs(prev_obj))
            if rel_change < tol:
                if verbose:
                    print(f"[Stop] iter={it} relative change={rel_change:.3e}")
                logs.append({"iter": it, "obj": obj_val,
                             "lse": float(parts["lse"]), "seq": float(parts["seq_penalty"]),
                             "cap": float(parts["cap_penalty"])})
                break
        prev_obj = obj_val

        # 搜索方向 d = - invH * g
        d = -invH.mv(g)

        # Armijo 回溯线搜索
        alpha = ls_alpha0
        with torch.no_grad():
            phi0 = obj_val
            slope = ls_c * g.dot(d).item()  # <0
            # 线搜索中需要频繁评估目标，但不能破坏计算图 -> 用 no_grad 做试探
            while True:
                theta_try = theta + alpha * d
                J_try, _ = model.objective(theta_try)
                phi_new = float(J_try.detach().cpu().item())
                if phi_new <= phi0 + alpha * slope:
                    break
                alpha *= ls_rho
                if alpha < 1e-8:
                    # 无法找到更好步长，退化为小步长或原地
                    break

        # BFGS 更新
        with torch.no_grad():
            theta_new = theta + alpha * d
        # 重新构图计算新梯度
        theta_new.requires_grad_(True)
        obj_new, parts_new = model.objective(theta_new)
        if theta_new.grad is not None:
            theta_new.grad.zero_()
        obj_new.backward()
        g_new = theta_new.grad.detach().clone()

        s = (theta_new.detach() - theta.detach())
        y = (g_new - g)
        ys = y.dot(s).item()

        # BFGS 逆 Hessian 更新：invH = (I - rho*s*y^T) invH (I - rho*y*s^T) + rho*s*s^T
        # rho = 1/(y^T s)
        if ys > 1e-12:
            rho = 1.0 / ys
            I = torch.eye(n, dtype=torch.float32, device=theta.device)
            syT = torch.ger(s, y)  # s y^T
            ysT = torch.ger(y, s)  # y s^T
            ssT = torch.ger(s, s)  # s s^T
            A = (I - rho * syT)
            invH = A @ invH @ A.T + rho * ssT
        else:
            # 跳过更新，保持 invH
            pass

        # 记录日志
        logs.append({
            "iter": it,
            "obj": float(obj_new.detach().cpu().item()),
            "alpha": float(alpha),
            "grad_norm": float(g_new.norm().cpu().item()),
            "lse": float(parts_new["lse"]),
            "seq": float(parts_new["seq_penalty"]),
            "cap": float(parts_new["cap_penalty"])
        })

        # 准备下一轮
        theta = theta_new

        if verbose and (it % 10 == 0 or it == 1):
            print(f"[Iter {it:03d}] obj={logs[-1]['obj']:.4f} |alpha={alpha:.2e}| "
                  f"||g||={logs[-1]['grad_norm']:.2e} | LSE={logs[-1]['lse']:.3f} "
                  f"| Seq={logs[-1]['seq']:.3f} | Cap={logs[-1]['cap']:.3f}")

    return theta.detach(), logs


# =========================
# 连续解 -> 可行离散调度（后处理）
# =========================
def make_feasible_schedule(ins: JSSPInstance, soft_starts: torch.Tensor) -> Tuple[Dict[Tuple[int, int], Tuple[float, float, int]], float]:
    """
    将优化得到的（连续）开始时间 soft_starts 转化为可行解：
    1) 按机器将操作按 soft_starts 排序；
    2) 对每台机器按序贪心排程；每个操作的实际开始 = max(同作业上一步完成, 该机可用)。
    返回：
      - sch[(job, op_idx)] = (start, finish, machine)
      - makespan
    """
    ops: List[Operation] = []
    for i in range(ins.num_jobs):
        for j, op in enumerate(ins.jobs[i]):
            ops.append(Operation(job=i, op_idx=j, machine=int(op["machine"]), duration=float(op["duration"])))
    op_index = {(op.job, op.op_idx): idx for idx, op in enumerate(ops)}

    # 初始化
    machine_ready = [0.0] * ins.num_machines
    job_ready = [0.0] * ins.num_jobs
    sch: Dict[Tuple[int, int], Tuple[float, float, int]] = {}

    # 每台机器上的操作，按 soft start 升序
    ops_by_m: Dict[int, List[Operation]] = {m: [] for m in range(ins.num_machines)}
    for op in ops:
        ops_by_m[op.machine].append(op)
    for m in range(ins.num_machines):
        ops_by_m[m].sort(key=lambda op: float(soft_starts[op_index[(op.job, op.op_idx)]].cpu()))

    # 调度（贪心）
    for m in range(ins.num_machines):
        for op in ops_by_m[m]:
            idx = op_index[(op.job, op.op_idx)]
            start = max(machine_ready[m], job_ready[op.job])
            finish = start + op.duration
            machine_ready[m] = finish
            job_ready[op.job] = finish
            sch[(op.job, op.op_idx)] = (start, finish, op.machine)

    makespan = max(job_ready)
    return sch, makespan


# =========================
# 可视化（Gantt）
# =========================
def plot_gantt(ins: JSSPInstance, schedule: Dict[Tuple[int, int], Tuple[float, float, int]]) -> None:
    """
    绘制 Gantt 图：横轴时间，纵轴机器；每个操作显示为该机器上的一段条形。
    注意：不设置任何特定颜色（遵循要求）。
    """
    plt.figure(figsize=(10, 5))
    yticks = []
    yticklabels = []

    for m in range(ins.num_machines):
        yticks.append(m)
        yticklabels.append(f"Machine {m}")
        # 取该机的所有操作并按开始时间排序
        items = [((i, j), v) for (i, j), v in schedule.items() if v[2] == m]
        items.sort(key=lambda kv: kv[1][0])
        for (i, j), (s, f, _) in items:
            plt.barh(m, (f - s), left=s)
            plt.text(s + 0.02, m, f"J{i}-O{j}", va="center", ha="left", fontsize=8)

    plt.yticks(yticks, yticklabels)
    plt.xlabel("Time")
    plt.title(f"Gantt Chart - {ins.instance_id}")
    plt.tight_layout()
    plt.show()


# =========================
# 示例与主流程
# =========================
def main():
    # STARJOB 示例实例（ft06）
    data = {
      "instance_id": "ft06",
      "num_jobs": 6,
      "num_machines": 6,
      "jobs": [
        [{"machine": 0, "duration": 5}, {"machine": 1, "duration": 1}, {"machine": 2, "duration": 3}, {"machine": 3, "duration": 6}, {"machine": 4, "duration": 5}, {"machine": 5, "duration": 4}],
        [{"machine": 0, "duration": 6}, {"machine": 1, "duration": 4}, {"machine": 2, "duration": 6}, {"machine": 3, "duration": 3}, {"machine": 4, "duration": 5}, {"machine": 5, "duration": 3}],
        [{"machine": 0, "duration": 2}, {"machine": 1, "duration": 5}, {"machine": 2, "duration": 5}, {"machine": 3, "duration": 1}, {"machine": 4, "duration": 4}, {"machine": 5, "duration": 6}],
        [{"machine": 0, "duration": 1}, {"machine": 1, "duration": 3}, {"machine": 2, "duration": 2}, {"machine": 3, "duration": 6}, {"machine": 4, "duration": 5}, {"machine": 5, "duration": 2}],
        [{"machine": 0, "duration": 4}, {"machine": 1, "duration": 6}, {"machine": 2, "duration": 3}, {"machine": 3, "duration": 2}, {"machine": 4, "duration": 5}, {"machine": 5, "duration": 3}],
        [{"machine": 0, "duration": 4}, {"machine": 1, "duration": 2}, {"machine": 2, "duration": 6}, {"machine": 3, "duration": 3}, {"machine": 4, "duration": 2}, {"machine": 5, "duration": 4}]
      ],
      "optimal_makespan": 51
    }
    ins = JSSPInstance.from_starjob_dict(data)

    # 模型构建（可根据需要调整权重）
    model = DifferentiableJSSP(
        ins,
        beta=10.0,       # LogSumExp 平滑强度（越大越接近 max，但数值更尖锐）
        lam_l2=1e-4,     # L2 正则
        w_seq=10.0,      # 顺序约束惩罚系数
        w_cap=10.0,      # 机器容量惩罚系数
        device="cpu"
    )

    # 拟牛顿 BFGS 优化
    theta_star, logs = bfgs_optimize(
        model,
        max_iters=200,
        tol=1e-6,
        ls_alpha0=1.0,
        ls_rho=0.5,
        ls_c=1e-4,
        verbose=True
    )

    # 连续解对应的软开始时间
    with torch.no_grad():
        soft_starts = model.soft_start_times(theta_star)

    # 后处理：转化为可行调度
    schedule, ms = make_feasible_schedule(ins, soft_starts)

    # 输出调度方案
    print("\n=== 可行调度方案（start, finish, machine） ===")
    for i in range(ins.num_jobs):
        for j in range(len(ins.jobs[i])):
            s, f, m = schedule[(i, j)]
            print(f"Job {i} - Op {j}: start={s:.2f}, finish={f:.2f}, machine={m}")
    print(f"\nMakespan (feasible postprocessed): {ms:.2f}")
    if ins.optimal_makespan is not None:
        print(f"Reference optimal makespan: {ins.optimal_makespan}")

    # 可视化
    plot_gantt(ins, schedule)


if __name__ == "__main__":
    main()
