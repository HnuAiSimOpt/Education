clear all
clc
%拉丁超立方取�?
%由于取样具有随机性，每次运行结果可能不同
X=40*lhsdesign(10,1)+100;
Y=6*lhsdesign(10,1)+20;
scatter(X(:,1),Y(:,1),'filled','m');
axis([100 140 20 26])
xlabel('宽度','Fontsize',12);
ylabel('肩部斜角','rotation',90,'Fontsize',12);
title('拉丁超立方取样结�','Fontsize',15)
grid on 