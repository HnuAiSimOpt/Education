<SOLUTION>
<LOADSTEPDATA>
<HEADER>
 <COLUMN ID="    1">Time</COLUMN>
 <COLUMN ID="    2">Load Step</COLUMN>
 <COLUMN ID="    3">Sub-step</COLUMN>
 <COLUMN ID="    4">Cum Iter</COLUMN>
 <COLUMN ID="    5">Time Incr</COLUMN>
 <COLUMN ID="    6">Max DOF Incr</COLUMN>
 <COLUMN ID="    7">Line Search Parameter</COLUMN>
 <COLUMN ID="    8">Bisection</COLUMN>
 <COLUMN ID="    9">F   CRIT</COLUMN>
 <COLUMN ID="   10">F    L2 </COLUMN>
 <COLUMN ID="   11">U   CRIT</COLUMN>
 <COLUMN ID="   12">U    INF</COLUMN>
 <COLUMN ID="   13">M   CRIT</COLUMN>
 <COLUMN ID="   14">M    L2 </COLUMN>
 <COLUMN ID="   15">Remesh</COLUMN>
 <COLUMN ID="   16">Max Resi F</COLUMN>
 <COLUMN ID="   17">Node with Max DOF Incr</COLUMN>
 <COLUMN ID="   18">DOF with Max DOF Incr</COLUMN>
 <COLUMN ID="   19">Node with Max Resi F</COLUMN>
 <COLUMN ID="   20">DOF with Max Resi F</COLUMN>
 <UNITS>MPA</UNITS>
</HEADER>
<COLDATA>
   0.2000000                    1                1                1    0.2000000       -0.3866014         0.000000                    0    0.3119131        0.7142653E-09    0.2012711E-01    0.3866014        0.6238262E-01    0.1669437E-10                0    0.1390932E-09                2             UY               1286             UX    
   0.2000000                    1                1                2    0.2000000        0.3100553E-09     0.000000                    0    0.3119131        0.7142653E-09    0.2012711E-01    0.3100553E-09    0.6238262E-01    0.1669437E-10                0    0.1390932E-09              162             UY               1361             UX    
   0.4000000                    1                2                3    0.2000000       -0.2182233E-15     0.000000                    0    0.6238262        0.2638207E-09    0.2012711E-01    0.2182233E-15    0.1247652        0.6836492E-12                0    0.3311851E-10              315             UY               1606             UY    
   0.7000000                    1                3                4    0.3000000       -0.9830646E-15     0.000000                    0     1.091696        0.5574285E-09    0.3019066E-01    0.9830646E-15    0.2183392        0.1307887E-11                0    0.8868659E-10              144             UY               1566             UY    
    1.000000                    1                4                5    0.3000000        0.2289550E-14     0.000000                    0     1.559566        0.7603736E-09    0.3019066E-01    0.2289550E-14    0.3119131        0.1630463E-11                0    0.1221403E-09              319             UY                749             UY    
</COLDATA>
</LOADSTEPDATA>
<LOADSTEPDATA>
<HEADER>
 <COLUMN ID="    1">Time</COLUMN>
 <COLUMN ID="    2">Load Step</COLUMN>
 <COLUMN ID="    3">Sub-step</COLUMN>
 <COLUMN ID="    4">Cum Iter</COLUMN>
 <COLUMN ID="    5">Time Incr</COLUMN>
 <COLUMN ID="    6">Max DOF Incr</COLUMN>
 <COLUMN ID="    7">Line Search Parameter</COLUMN>
 <COLUMN ID="    8">Bisection</COLUMN>
 <COLUMN ID="    9">F   CRIT</COLUMN>
 <COLUMN ID="   10">F    L2 </COLUMN>
 <COLUMN ID="   11">U   CRIT</COLUMN>
 <COLUMN ID="   12">U    INF</COLUMN>
 <COLUMN ID="   13">M   CRIT</COLUMN>
 <COLUMN ID="   14">M    L2 </COLUMN>
 <COLUMN ID="   15">Remesh</COLUMN>
 <COLUMN ID="   16">Max Resi F</COLUMN>
 <COLUMN ID="   17">Node with Max DOF Incr</COLUMN>
 <COLUMN ID="   18">DOF with Max DOF Incr</COLUMN>
 <COLUMN ID="   19">Node with Max Resi F</COLUMN>
 <COLUMN ID="   20">DOF with Max Resi F</COLUMN>
 <UNITS>MPA</UNITS>
</HEADER>
<COLDATA>
    1.200000                    2                1                6    0.2000000       -0.1013427E-14     0.000000                    0     1.559566        0.8430737E-09    0.3019066E-01    0.1013427E-14    0.3119131        0.1719918E-11                0    0.1130290E-09             1277             UY               1566             UY    
    1.400000                    2                2                7    0.2000000        0.1379490E-14     0.000000                    0     1.559566        0.8036597E-09    0.3019066E-01    0.1379490E-14    0.3119131        0.1886736E-11                0    0.1126088E-09             1277             UY                764             UY    
    1.700000                    2                3                8    0.3000000       -0.1823458E-14     0.000000                    0     1.559566        0.7671963E-09    0.3019066E-01    0.1823458E-14    0.3119131        0.1819749E-11                0    0.1099804E-09              733             UY                981             UY    
    2.000000                    2                4                9    0.3000000       -0.1194146E-14     0.000000                    0     1.559566        0.7976187E-09    0.3019066E-01    0.1194146E-14    0.3119131        0.1668652E-11                0    0.1038156E-09             1307             UY               1028             UY    
</COLDATA>
</LOADSTEPDATA>
<LOADSTEPDATA>
<HEADER>
 <COLUMN ID="    1">Time</COLUMN>
 <COLUMN ID="    2">Load Step</COLUMN>
 <COLUMN ID="    3">Sub-step</COLUMN>
 <COLUMN ID="    4">Cum Iter</COLUMN>
 <COLUMN ID="    5">Time Incr</COLUMN>
 <COLUMN ID="    6">Max DOF Incr</COLUMN>
 <COLUMN ID="    7">Line Search Parameter</COLUMN>
 <COLUMN ID="    8">Bisection</COLUMN>
 <COLUMN ID="    9">F   CRIT</COLUMN>
 <COLUMN ID="   10">F    L2 </COLUMN>
 <COLUMN ID="   11">U   CRIT</COLUMN>
 <COLUMN ID="   12">U    INF</COLUMN>
 <COLUMN ID="   13">M   CRIT</COLUMN>
 <COLUMN ID="   14">M    L2 </COLUMN>
 <COLUMN ID="   15">Remesh</COLUMN>
 <COLUMN ID="   16">Max Resi F</COLUMN>
 <COLUMN ID="   17">Node with Max DOF Incr</COLUMN>
 <COLUMN ID="   18">DOF with Max DOF Incr</COLUMN>
 <COLUMN ID="   19">Node with Max Resi F</COLUMN>
 <COLUMN ID="   20">DOF with Max Resi F</COLUMN>
 <UNITS>MPA</UNITS>
</HEADER>
<COLDATA>
    2.200000                    3                1               10    0.2000000        0.7304279E-15     0.000000                    0     1.559566        0.7865067E-09    0.3019066E-01    0.7304279E-15    0.3119131        0.1684166E-11                0    0.9487167E-10             1308             UY               1029             UY    
    2.400000                    3                2               11    0.2000000       -0.1135803E-14     0.000000                    0     1.559566        0.7780119E-09    0.3019066E-01    0.1135803E-14    0.3119131        0.1700131E-11                0    0.9889445E-10              185             UY                980             UY    
    2.700000                    3                3               12    0.3000000        0.2630328E-14     0.000000                    0     1.559566        0.7797298E-09    0.3019066E-01    0.2630328E-14    0.3119131        0.1829104E-11                0    0.9295342E-10              763             UY               1273             UY    
    3.000000                    3                4               13    0.3000000       -0.3562220E-14     0.000000                    0     1.559566        0.7957054E-09    0.3019066E-01    0.3562220E-14    0.3119131        0.1724064E-11                0    0.9885093E-10              312             UY                985             UY    
</COLDATA>
</LOADSTEPDATA>
<LOADSTEPDATA>
<HEADER>
 <COLUMN ID="    1">Time</COLUMN>
 <COLUMN ID="    2">Load Step</COLUMN>
 <COLUMN ID="    3">Sub-step</COLUMN>
 <COLUMN ID="    4">Cum Iter</COLUMN>
 <COLUMN ID="    5">Time Incr</COLUMN>
 <COLUMN ID="    6">Max DOF Incr</COLUMN>
 <COLUMN ID="    7">Line Search Parameter</COLUMN>
 <COLUMN ID="    8">Bisection</COLUMN>
 <COLUMN ID="    9">F   CRIT</COLUMN>
 <COLUMN ID="   10">F    L2 </COLUMN>
 <COLUMN ID="   11">U   CRIT</COLUMN>
 <COLUMN ID="   12">U    INF</COLUMN>
 <COLUMN ID="   13">M   CRIT</COLUMN>
 <COLUMN ID="   14">M    L2 </COLUMN>
 <COLUMN ID="   15">Remesh</COLUMN>
 <COLUMN ID="   16">Max Resi F</COLUMN>
 <COLUMN ID="   17">Node with Max DOF Incr</COLUMN>
 <COLUMN ID="   18">DOF with Max DOF Incr</COLUMN>
 <COLUMN ID="   19">Node with Max Resi F</COLUMN>
 <COLUMN ID="   20">DOF with Max Resi F</COLUMN>
 <UNITS>MPA</UNITS>
</HEADER>
<COLDATA>
    3.200000                    4                1               14    0.2000000       -0.1547232E-14     0.000000                    0     1.559566        0.8054726E-09    0.3019066E-01    0.1547232E-14    0.3119131        0.1707784E-11                0    0.9883888E-10              167             UY               1259             UY    
    3.400000                    4                2               15    0.2000000        0.3303797E-14     0.000000                    0     1.559566        0.7216653E-09    0.3019066E-01    0.3303797E-14    0.3119131        0.1689392E-11                0    0.9398482E-10              144             UY               1278             UY    
    3.700000                    4                3               16    0.3000000       -0.3399947E-14     0.000000                    0     1.559566        0.7637440E-09    0.3019066E-01    0.3399947E-14    0.3119131        0.1772732E-11                0    0.1149797E-09             1257             UY               1246             UY    
    4.000000                    4                4               17    0.3000000        0.1428225E-14     0.000000                    0     1.559566        0.7913923E-09    0.3019066E-01    0.1428225E-14    0.3119131        0.1668086E-11                0    0.9833157E-10              985             UY                791             UY    
</COLDATA>
</LOADSTEPDATA>
</SOLUTION>
