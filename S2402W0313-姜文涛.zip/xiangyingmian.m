% =============================================
% 响应面方法优化四个参数 x1, x2, x3, x4
% 使用给定的线性响应面方程
% =============================================

clc; clear; close all;

%% 步骤1: 定义参数范围和响应面方程
% 根据提供的信息设置参数范围
param_range = [
    1   5;    % x1范围 (1, 5)
    45  55;   % x2范围 (45, 55)
    1.5 2.5;  % x3范围 (1.5, 2.5)
    270 290;  % x4范围 (270, 290)
];

% 给定的响应面方程
rsm_equation = @(x) 154.65277 - 0.2255*x(1) - 0.97487*x(2) - 2.92733*x(3) - 0.011783*x(4);

%% 步骤2: 定义目标函数（如果需要验证实际响应）
% 注意：这里使用给定的响应面方程作为目标函数
% 如果您有实际的目标函数，请替换下面的定义
objective_function = rsm_equation;

%% 步骤3: 直接使用响应面方程进行优化
% 设置优化选项
options = optimoptions('fmincon', 'Display', 'iter', 'Algorithm', 'sqp');

% 定义约束条件
A = []; b = [];
Aeq = []; beq = [];
lb = param_range(:, 1)'; % 参数下限
ub = param_range(:, 2)'; % 参数上限

% 初始猜测（参数范围的中心点）
x0 = zeros(1, 4);
for i = 1:4
    x0(i) = (param_range(i, 1) + param_range(i, 2)) / 2;
end

% 在实际参数空间进行优化
[actual_opt, fval] = fmincon(@(x) rsm_equation(x), x0, A, b, Aeq, beq, lb, ub, [], options);

%% 步骤4: 结果验证与输出
% 计算实际目标函数值（如果与实际目标函数不同）
actual_response = objective_function(actual_opt);

% 显示优化结果
disp('======= 优化结果 =======');
fprintf('优化参数: x1=%.4f, x2=%.4f, x3=%.4f, x4=%.4f\n', actual_opt);
fprintf('预测响应值: %.4f\n', fval);
fprintf('实际响应值: %.4f\n', actual_response);

% 显示参数敏感度分析
disp('======= 参数敏感度分析 =======');
fprintf('x1系数: %.6f (每单位变化对响应的影响)\n', -0.2255);
fprintf('x2系数: %.6f (每单位变化对响应的影响)\n', -0.97487);
fprintf('x3系数: %.6f (每单位变化对响应的影响)\n', -2.92733);
fprintf('x4系数: %.6f (每单位变化对响应的影响)\n', -0.011783);

%% 步骤5: 绘制响应面图 (使用x2和x3作为变量)
% 固定x1和x4在最优值，变化x2和x3
[x2_grid, x3_grid] = meshgrid(linspace(param_range(2,1), param_range(2,2), 20), ...
                              linspace(param_range(3,1), param_range(3,2), 20));
z = zeros(size(x2_grid));

for i = 1:size(x2_grid,1)
    for j = 1:size(x2_grid,2)
        % 固定x1和x4在最优值，变化x2和x3
        test_point = [actual_opt(1), x2_grid(i,j), x3_grid(i,j), actual_opt(4)];
        z(i,j) = rsm_equation(test_point);
    end
end

% 绘制响应面
figure;
surf(x2_grid, x3_grid, z);
xlabel('x2'); ylabel('x3'); zlabel('响应值');
title('响应面模型 (x2-x3平面)');
colorbar;

% 添加等高线图
figure;
contour(x2_grid, x3_grid, z, 20);
xlabel('x2'); ylabel('x3');
title('响应面等高线图 (x2-x3平面)');
colorbar;

% 绘制优化点在响应面上的位置
figure;
contour(x2_grid, x3_grid, z, 20);
hold on;
plot(actual_opt(2), actual_opt(3), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
text(actual_opt(2)+0.1, actual_opt(3)+0.1, '最优点', 'FontSize', 12);
xlabel('x2'); ylabel('x3');
title('响应面等高线图与最优点位置');
colorbar;
hold off;

%% 步骤6: 参数影响分析
% 创建单参数变化的影响图
figure;
subplot(2,2,1);
x1_vals = linspace(param_range(1,1), param_range(1,2), 20);
y1 = arrayfun(@(x) rsm_equation([x, actual_opt(2), actual_opt(3), actual_opt(4)]), x1_vals);
plot(x1_vals, y1);
xlabel('x1'); ylabel('响应值');
title('x1对响应值的影响');

subplot(2,2,2);
x2_vals = linspace(param_range(2,1), param_range(2,2), 20);
y2 = arrayfun(@(x) rsm_equation([actual_opt(1), x, actual_opt(3), actual_opt(4)]), x2_vals);
plot(x2_vals, y2);
xlabel('x2'); ylabel('响应值');
title('x2对响应值的影响');

subplot(2,2,3);
x3_vals = linspace(param_range(3,1), param_range(3,2), 20);
y3 = arrayfun(@(x) rsm_equation([actual_opt(1), actual_opt(2), x, actual_opt(4)]), x3_vals);
plot(x3_vals, y3);
xlabel('x3'); ylabel('响应值');
title('x3对响应值的影响');

subplot(2,2,4);
x4_vals = linspace(param_range(4,1), param_range(4,2), 20);
y4 = arrayfun(@(x) rsm_equation([actual_opt(1), actual_opt(2), actual_opt(3), x]), x4_vals);
plot(x4_vals, y4);
xlabel('x4'); ylabel('响应值');
title('x4对响应值的影响');

% 调整子图间距
sgtitle('各参数对响应值的影响');
